import React from 'react';
import { VaultPage } from './components/VaultPage';
export function App() {
  return <VaultPage />;
}