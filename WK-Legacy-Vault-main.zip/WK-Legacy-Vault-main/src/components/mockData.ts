export interface LegacyFile {
  id: string;
  name: string;
  date: string;
  market: string;
  isci: string;
  media: string;
  description: string;
  rotation: number;
}

export const mockFiles: LegacyFile[] = [
{
  id: 'f1',
  name: 'Nike_HolidayPush_2018_30s.mov',
  date: 'Nov 12, 2018',
  market: 'US National',
  isci: 'NKHL1830000H',
  media: 'TV Broadcast',
  description:
  'Final master for the 2018 Holiday campaign featuring winter athletes. Includes updated end tag.',
  rotation: -0.5
},
{
  id: 'f2',
  name: 'Coca-Cola_SuperBowl_2016_Master.mp4',
  date: 'Jan 28, 2016',
  market: 'Global',
  isci: 'CCSB1660000H',
  media: 'Digital & TV',
  description:
  'The 60s hero spot for Super Bowl 50. Color graded by Company 3. Audio mixed for stadium broadcast.',
  rotation: 0.3
},
{
  id: 'f3',
  name: 'Apple_iPhoneX_Reveal_Keynote.prores',
  date: 'Sep 05, 2017',
  market: 'WW',
  isci: 'APPLIXRVL000',
  media: 'Event / Digital',
  description:
  'Uncompressed ProRes master of the iPhone X reveal video used during the September keynote.',
  rotation: -0.2
},
{
  id: 'f4',
  name: 'Spotify_Wrapped_2020_OOH_TimesSquare.zip',
  date: 'Nov 20, 2020',
  market: 'US - NY',
  isci: 'SPOWR20OOHNY',
  media: 'OOH Digital',
  description:
  'Animated billboard assets for Times Square takeover. Includes 4k and 8k vertical renders.',
  rotation: 0.6
},
{
  id: 'f5',
  name: 'OldSpice_TheMan_DirectorCut.mp4',
  date: 'Feb 14, 2010',
  market: 'US National',
  isci: 'OSMAN1060000',
  media: 'TV Broadcast',
  description:
  "Original director's cut before network standards & practices revisions. Retained for archival reference.",
  rotation: -0.4
},
{
  id: 'f6',
  name: 'Airbnb_MadePossible_Host_Stories.mp4',
  date: 'May 10, 2021',
  market: 'EMEA',
  isci: 'ABMP21EMEA00',
  media: 'Social / YouTube',
  description:
  'Compilation of host stories for the EMEA region launch of the "Made Possible by Hosts" campaign.',
  rotation: 0.1
}];


// ---------- Instructions ----------

export interface ScheduleRow {
  flight: string;
  isci: string;
  title: string;
  dur: string;
  rot: string;
  schedule: string;
}

export interface ScheduleGroup {
  label: string;
  tone: 'lavender' | 'rose' | 'sage' | 'sand' | 'blush';
  rows: ScheduleRow[];
}

export interface CreativeFileLink {
  isci: string;
  title: string;
}

export interface Instruction {
  id: string;
  client: string;
  agency: string;
  market: string;
  buyer: string;
  estimate: string;
  media: string;
  month: string;
  flight: string;
  version: string;
  comments: string;
  driveLink: string;
  groups: ScheduleGroup[];
  creativeFiles: CreativeFileLink[];
  rotation: number;
}

export const mockInstructions: Instruction[] = [
{
  id: 'i1',
  client: 'Wettermark Keith',
  agency: 'Atticor Media',
  market: 'Huntsville',
  buyer: 'Amy Coffey',
  estimate: '214',
  media: 'TV',
  month: 'May',
  flight: '4/27 — 5/31',
  version: 'V2',
  comments:
  'Revised May Traffic — if any creative is missing please check this Google Drive link.',
  driveLink: 'https://drive.google.com/folders/1qz0ob55u',
  rotation: -0.3,
  groups: [
  {
    label: 'M-F Schedule',
    tone: 'lavender',
    rows: [
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2530007T',
      title: 'Different_30',
      dur: ':30',
      rot: '30%',
      schedule: 'M-F Schedule'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2630003T',
      title: "Mother's Wreck_30",
      dur: ':30',
      rot: '20%',
      schedule: 'M-F Schedule'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2630010T',
      title: 'Strength in Confidence_30',
      dur: ':30',
      rot: '50%',
      schedule: 'M-F Schedule'
    }]

  },
  {
    label: 'Weekend Schedule',
    tone: 'sand',
    rows: [
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2630006T',
      title: 'Weekends_30',
      dur: ':30',
      rot: '50%',
      schedule: 'Weekend Schedule'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2630004T',
      title: 'Personal_30',
      dur: ':30',
      rot: '50%',
      schedule: 'Weekend Schedule'
    }]

  },
  {
    label: 'All Week',
    tone: 'sage',
    rows: [
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2615007T',
      title: "Mother's Wreck_15",
      dur: ':15',
      rot: '100%',
      schedule: 'All Week'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2610002T',
      title: 'Premise Injury_10',
      dur: ':10',
      rot: '50%',
      schedule: 'All Week'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2610001T',
      title: 'Car Wreck_10',
      dur: ':10',
      rot: '50%',
      schedule: 'All Week'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2605002T',
      title: 'Premise Injury_5',
      dur: ':05',
      rot: '50%',
      schedule: 'All Week'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2605001T',
      title: 'Car Wreck_05',
      dur: ':05',
      rot: '50%',
      schedule: 'All Week'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2604001T',
      title: 'Personal_04',
      dur: ':04',
      rot: '100%',
      schedule: 'All Week'
    }]

  },
  {
    label: 'M-F Bookend',
    tone: 'rose',
    rows: [
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2515010T',
      title: 'Different_15',
      dur: ':15',
      rot: '16.5%',
      schedule: 'Bookend :15 A'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2515008T',
      title: 'Commercial Accident_15',
      dur: ':15',
      rot: '16.5%',
      schedule: 'Bookend :15 A'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2515011T',
      title: 'More To Us 15',
      dur: ':15',
      rot: '16.5%',
      schedule: 'Bookend :15 B'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2515008T',
      title: 'Commercial Accident_15',
      dur: ':15',
      rot: '16.5%',
      schedule: 'Bookend :15 B'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2515009T',
      title: 'Distracted Cell Phones_15',
      dur: ':15',
      rot: '16.5%',
      schedule: 'Bookend :15 C'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2615007T',
      title: "Mother's Wreck_15",
      dur: ':15',
      rot: '16.5%',
      schedule: 'Bookend :15 C'
    }]

  },
  {
    label: 'Weekend Bookend',
    tone: 'blush',
    rows: [
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2615002T',
      title: 'Weekends_15',
      dur: ':15',
      rot: '25%',
      schedule: 'Bookend :15 A'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2515008T',
      title: 'Commercial Accident_15',
      dur: ':15',
      rot: '25%',
      schedule: 'Bookend :15 A'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2515008T',
      title: 'Trucking One_15',
      dur: ':15',
      rot: '25%',
      schedule: 'Bookend :15 B'
    },
    {
      flight: '4/27 — 5/31',
      isci: 'HSVWK2615002T',
      title: 'Weekends_15',
      dur: ':15',
      rot: '25%',
      schedule: 'Bookend :15 B'
    }]

  }],

  creativeFiles: [
  { isci: 'HSVWK2530007T', title: 'Different_30' },
  { isci: 'HSVWK2630003T', title: "Mother's Wreck_30" },
  { isci: 'HSVWK2630010T', title: 'Strength in Confidence_30' },
  { isci: 'HSVWK2630006T', title: 'Weekends_30' },
  { isci: 'HSVWK2630004T', title: 'Personal_30' },
  { isci: 'HSVWK2515010T', title: 'Different_15' },
  { isci: 'HSVWK2515011T', title: 'More To Us 15' },
  { isci: 'HSVWK2515008T', title: 'Commercial Accident_15' },
  { isci: 'HSVWK2515009T', title: 'Distracted Cell Phones_15' },
  { isci: 'HSVWK2615007T', title: "Mother's Wreck_15" },
  { isci: 'HSVWK2615002T', title: 'Weekends_15' }]

},
{
  id: 'i2',
  client: 'Wettermark Keith',
  agency: 'Atticor Media',
  market: 'Birmingham',
  buyer: 'Amy Coffey',
  estimate: '218',
  media: 'TV',
  month: 'June',
  flight: '6/01 — 6/28',
  version: 'V1',
  comments:
  'June flight launch. New "Strength in Confidence" hero in heavy rotation across M-F and All Week.',
  driveLink: 'https://drive.google.com/folders/2bm1xa44k',
  rotation: 0.4,
  groups: [
  {
    label: 'M-F Schedule',
    tone: 'lavender',
    rows: [
    {
      flight: '6/01 — 6/28',
      isci: 'BHMWK2630010T',
      title: 'Strength in Confidence_30',
      dur: ':30',
      rot: '60%',
      schedule: 'M-F Schedule'
    },
    {
      flight: '6/01 — 6/28',
      isci: 'BHMWK2630003T',
      title: "Mother's Wreck_30",
      dur: ':30',
      rot: '40%',
      schedule: 'M-F Schedule'
    }]

  },
  {
    label: 'All Week',
    tone: 'sage',
    rows: [
    {
      flight: '6/01 — 6/28',
      isci: 'BHMWK2615007T',
      title: "Mother's Wreck_15",
      dur: ':15',
      rot: '75%',
      schedule: 'All Week'
    },
    {
      flight: '6/01 — 6/28',
      isci: 'BHMWK2610001T',
      title: 'Car Wreck_10',
      dur: ':10',
      rot: '25%',
      schedule: 'All Week'
    }]

  },
  {
    label: 'Weekend Bookend',
    tone: 'blush',
    rows: [
    {
      flight: '6/01 — 6/28',
      isci: 'BHMWK2615002T',
      title: 'Weekends_15',
      dur: ':15',
      rot: '50%',
      schedule: 'Bookend :15 A'
    },
    {
      flight: '6/01 — 6/28',
      isci: 'BHMWK2515008T',
      title: 'Trucking One_15',
      dur: ':15',
      rot: '50%',
      schedule: 'Bookend :15 B'
    }]

  }],

  creativeFiles: [
  { isci: 'BHMWK2630010T', title: 'Strength in Confidence_30' },
  { isci: 'BHMWK2630003T', title: "Mother's Wreck_30" },
  { isci: 'BHMWK2615007T', title: "Mother's Wreck_15" },
  { isci: 'BHMWK2610001T', title: 'Car Wreck_10' },
  { isci: 'BHMWK2615002T', title: 'Weekends_15' },
  { isci: 'BHMWK2515008T', title: 'Trucking One_15' }]

},
{
  id: 'i3',
  client: 'Wettermark Keith',
  agency: 'Atticor Media',
  market: 'Mobile',
  buyer: 'Jordan Pace',
  estimate: '221',
  media: 'TV',
  month: 'July',
  flight: '7/06 — 8/02',
  version: 'V1',
  comments:
  'Summer flight. Heavy weekend bookend allocation; please confirm Trucking One :15 master before air.',
  driveLink: 'https://drive.google.com/folders/3kp2yc88p',
  rotation: -0.2,
  groups: [
  {
    label: 'Weekend Schedule',
    tone: 'sand',
    rows: [
    {
      flight: '7/06 — 8/02',
      isci: 'MOBWK2630006T',
      title: 'Weekends_30',
      dur: ':30',
      rot: '60%',
      schedule: 'Weekend Schedule'
    },
    {
      flight: '7/06 — 8/02',
      isci: 'MOBWK2630004T',
      title: 'Personal_30',
      dur: ':30',
      rot: '40%',
      schedule: 'Weekend Schedule'
    }]

  },
  {
    label: 'Weekend Bookend',
    tone: 'blush',
    rows: [
    {
      flight: '7/06 — 8/02',
      isci: 'MOBWK2615002T',
      title: 'Weekends_15',
      dur: ':15',
      rot: '33%',
      schedule: 'Bookend :15 A'
    },
    {
      flight: '7/06 — 8/02',
      isci: 'MOBWK2515008T',
      title: 'Trucking One_15',
      dur: ':15',
      rot: '33%',
      schedule: 'Bookend :15 B'
    },
    {
      flight: '7/06 — 8/02',
      isci: 'MOBWK2515008T',
      title: 'Commercial Accident_15',
      dur: ':15',
      rot: '34%',
      schedule: 'Bookend :15 C'
    }]

  }],

  creativeFiles: [
  { isci: 'MOBWK2630006T', title: 'Weekends_30' },
  { isci: 'MOBWK2630004T', title: 'Personal_30' },
  { isci: 'MOBWK2615002T', title: 'Weekends_15' },
  { isci: 'MOBWK2515008T', title: 'Trucking One_15' },
  { isci: 'MOBWK2515008T', title: 'Commercial Accident_15' }]

}];