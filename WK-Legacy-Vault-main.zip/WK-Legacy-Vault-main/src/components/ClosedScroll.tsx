import React from 'react';
import { motion } from 'framer-motion';
const SCROLL_IMAGE = "/antique-gold-scroll-with-wax-seal-vector-826116.jpg";

interface ClosedScrollProps {
  client: string;
  month: string;
  flight: string;
  market: string;
  version: string;
  isOpen: boolean;
  onClick: () => void;
  seedRotation?: number;
}
/**
 * ClosedScroll — compact rolled scroll with the market & month inscribed
 * directly on the parchment so we can fit many per page.
 *
 * Text sits on the flat panels on either side of the wax seal.
 */
export function ClosedScroll({
  client,
  month,
  flight,
  market,
  version,
  isOpen,
  onClick,
  seedRotation = 0
}: ClosedScrollProps) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={{
        y: -3,
        scale: 1.04
      }}
      whileTap={{
        scale: 0.98
      }}
      transition={{
        type: 'spring',
        stiffness: 320,
        damping: 22
      }}
      style={{
        rotate: `${seedRotation}deg`
      }}
      className="block text-left relative group focus:outline-none"
      aria-expanded={isOpen}
      title={`${market} · ${month} · ${flight} · ${version}`}>
      
      {/* Hidden SVG defs — color-key filter that turns white → transparent. */}
      <svg
        width="0"
        height="0"
        style={{
          position: 'absolute',
          width: 0,
          height: 0
        }}
        aria-hidden="true">
        
        <defs>
          <filter id="scroll-key-out" colorInterpolationFilters="sRGB">
            <feColorMatrix
              type="matrix"
              values="
                1 0 0 0 0
                0 1 0 0 0
                0 0 1 0 0
                -1.667 -1.667 -1.667 5 0
              " />





            
          </filter>
        </defs>
      </svg>

      {/* Warm torch glow behind the scroll (only on hover, to avoid noise when packed) */}
      <div
        className="absolute -inset-2 rounded-2xl opacity-0 group-hover:opacity-90 transition-opacity duration-300 pointer-events-none blur-xl"
        style={{
          background:
          'radial-gradient(ellipse 70% 60% at 50% 50%, rgba(212,168,87,0.55) 0%, rgba(160,40,80,0.25) 50%, transparent 80%)'
        }}>
      </div>

      {/* Scroll artwork — background removed via SVG color-key filter */}
      <div
        className="relative w-[240px]"
        style={{
          aspectRatio: '1000 / 220'
        }}>
        
        <div
          className="absolute inset-0 bg-no-repeat bg-center bg-contain"
          style={{
            backgroundImage: `url(${SCROLL_IMAGE})`,
            filter:
            'url(#scroll-key-out) drop-shadow(0 4px 8px rgba(0,0,0,0.55))'
          }}>
        </div>

        {/* MARKET — left flat panel of the scroll */}
        <div
          className="absolute flex items-center justify-center text-center pointer-events-none"
          style={{
            left: '9%',
            right: '63%',
            top: '24%',
            bottom: '24%'
          }}>
          
          <span
            className="font-cinzel font-bold uppercase leading-tight"
            style={{
              fontSize: market.length > 10 ? 8 : 10,
              letterSpacing: '0.12em',
              color: '#3a2510',
              textShadow: '0 1px 0 rgba(255,235,180,0.4)'
            }}>
            
            {market}
          </span>
        </div>

        {/* MONTH / VERSION — right flat panel of the scroll */}
        <div
          className="absolute flex flex-col items-center justify-center text-center pointer-events-none"
          style={{
            left: '63%',
            right: '9%',
            top: '22%',
            bottom: '22%'
          }}>
          
          <span
            className="font-cinzel font-bold uppercase leading-tight"
            style={{
              fontSize: 10,
              letterSpacing: '0.12em',
              color: '#3a2510',
              textShadow: '0 1px 0 rgba(255,235,180,0.4)'
            }}>
            
            {month}
          </span>
          <span
            className="font-cinzel font-semibold uppercase mt-0.5"
            style={{
              fontSize: 7,
              letterSpacing: '0.2em',
              color: '#5a3a18',
              opacity: 0.85
            }}>
            
            {version}
          </span>
        </div>
      </div>
    </motion.button>);

}