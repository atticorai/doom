import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
/**
 * VaultAtmosphere
 *
 * The mystical, mythological backdrop of the vault. Layered behind all
 * content. Composed of:
 *   - Two slow-pulsing magenta + violet radial glows (underworld energy)
 *   - Floating soul-embers drifting upward
 *   - Ionic columns flanking the page (SVG)
 *   - A repeating Greek key (meander) border across the top
 *   - Wall sconces in the upper corners with flickering flames
 *   - A faint laurel medallion watermark at the very back
 */
export function VaultAtmosphere() {
  const embers = useMemo(
    () =>
    Array.from({
      length: 22
    }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 12,
      duration: 14 + Math.random() * 10,
      size: 2 + Math.random() * 3,
      hue: Math.random() > 0.4 ? 'magenta' : 'gold',
      drift: (Math.random() - 0.5) * 60
    })),
    []
  );
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {/* Vignette + ambient underworld glow */}
      <motion.div
        className="absolute inset-0"
        style={{
          background:
          'radial-gradient(ellipse 80% 60% at 50% 10%, rgba(160,40,80,0.35) 0%, rgba(122,31,61,0.18) 30%, transparent 60%)'
        }}
        animate={{
          opacity: [0.7, 1, 0.7]
        }}
        transition={{
          duration: 9,
          repeat: Infinity,
          ease: 'easeInOut'
        }} />
      
      <motion.div
        className="absolute inset-0"
        style={{
          background:
          'radial-gradient(ellipse 70% 50% at 30% 80%, rgba(90,40,140,0.22) 0%, transparent 55%), radial-gradient(ellipse 70% 50% at 70% 70%, rgba(160,40,120,0.18) 0%, transparent 55%)'
        }}
        animate={{
          opacity: [0.85, 1, 0.85]
        }}
        transition={{
          duration: 11,
          repeat: Infinity,
          ease: 'easeInOut',
          delay: 2
        }} />
      

      {/* Heavy dark vignette at edges (the vault closes in) */}
      <div className="absolute inset-0 shadow-[inset_0_0_220px_rgba(0,0,0,0.85)]"></div>

      {/* Laurel medallion watermark — faint, dead-center, very back */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.05]">
        <LaurelMedallion />
      </div>

      {/* Greek key (meander) border across the top */}
      <div className="absolute top-0 left-0 right-0 h-3 opacity-50">
        <MeanderBand />
      </div>
      <div className="absolute top-3 left-0 right-0 h-px bg-gradient-to-r from-transparent via-megara-gold/40 to-transparent"></div>

      {/* Columns flanking the page */}
      <div className="absolute left-0 top-3 bottom-0 w-16 sm:w-24 lg:w-32 opacity-80">
        <IonicColumn />
      </div>
      <div className="absolute right-0 top-3 bottom-0 w-16 sm:w-24 lg:w-32 opacity-80 scale-x-[-1]">
        <IonicColumn />
      </div>

      {/* Wall sconces with flickering flames */}
      <div className="absolute top-10 left-4 sm:left-8 lg:left-16">
        <Sconce />
      </div>
      <div className="absolute top-10 right-4 sm:right-8 lg:right-16 scale-x-[-1]">
        <Sconce />
      </div>

      {/* Drifting soul-embers */}
      {embers.map((e) =>
      <motion.div
        key={e.id}
        className="absolute rounded-full"
        style={{
          left: `${e.left}%`,
          bottom: -10,
          width: e.size,
          height: e.size,
          background:
          e.hue === 'magenta' ?
          'radial-gradient(circle, rgba(220,120,180,0.95) 0%, rgba(160,40,100,0.6) 50%, transparent 80%)' :
          'radial-gradient(circle, rgba(255,220,140,0.95) 0%, rgba(212,168,87,0.55) 50%, transparent 80%)',
          boxShadow:
          e.hue === 'magenta' ?
          '0 0 8px rgba(220,120,180,0.7)' :
          '0 0 8px rgba(255,220,140,0.7)'
        }}
        animate={{
          y: ['0vh', '-110vh'],
          x: [0, e.drift, -e.drift / 2, e.drift / 3, 0],
          opacity: [0, 0.9, 0.7, 0.4, 0],
          scale: [0.6, 1.1, 1, 0.9, 0.4]
        }}
        transition={{
          duration: e.duration,
          delay: e.delay,
          repeat: Infinity,
          ease: 'easeOut'
        }} />

      )}
    </div>);

}
/* ---------- Sub-pieces ---------- */
function MeanderBand() {
  // Subtle Greek key pattern using SVG, repeated horizontally
  return (
    <svg
      width="100%"
      height="12"
      viewBox="0 0 80 12"
      preserveAspectRatio="repeat"
      xmlns="http://www.w3.org/2000/svg">
      
      <defs>
        <pattern
          id="meander"
          x="0"
          y="0"
          width="40"
          height="12"
          patternUnits="userSpaceOnUse">
          
          <path
            d="M0 11 V3 H30 V8 H10 V5 H25 V11 Z"
            fill="none"
            stroke="#d4a857"
            strokeWidth="0.6"
            opacity="0.85" />
          
        </pattern>
      </defs>
      <rect width="100%" height="12" fill="url(#meander)" />
    </svg>);

}
function IonicColumn() {
  // Stylized Ionic column SVG — capital w/ volutes at top, fluted shaft, base.
  // The svg stretches vertically so the shaft fills available height.
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 60 800"
      preserveAspectRatio="none"
      xmlns="http://www.w3.org/2000/svg"
      className="block">
      
      <defs>
        <linearGradient id="stone" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#2a1830" />
          <stop offset="20%" stopColor="#5a3a60" />
          <stop offset="50%" stopColor="#8a6da0" />
          <stop offset="80%" stopColor="#5a3a60" />
          <stop offset="100%" stopColor="#2a1830" />
        </linearGradient>
        <linearGradient id="stoneDark" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#1a0c20" />
          <stop offset="50%" stopColor="#4a2a50" />
          <stop offset="100%" stopColor="#1a0c20" />
        </linearGradient>
      </defs>

      {/* Capital (top) — abacus + volutes */}
      <rect x="2" y="0" width="56" height="6" fill="url(#stoneDark)" />
      <rect x="0" y="6" width="60" height="4" fill="url(#stone)" />
      {/* Volute scrolls */}
      <g transform="translate(0,10)">
        <rect x="2" y="0" width="56" height="14" fill="url(#stone)" />
        <circle
          cx="10"
          cy="7"
          r="5"
          fill="none"
          stroke="#d4a857"
          strokeWidth="0.8"
          opacity="0.7" />
        
        <circle
          cx="10"
          cy="7"
          r="2.5"
          fill="none"
          stroke="#d4a857"
          strokeWidth="0.6"
          opacity="0.7" />
        
        <circle
          cx="50"
          cy="7"
          r="5"
          fill="none"
          stroke="#d4a857"
          strokeWidth="0.8"
          opacity="0.7" />
        
        <circle
          cx="50"
          cy="7"
          r="2.5"
          fill="none"
          stroke="#d4a857"
          strokeWidth="0.6"
          opacity="0.7" />
        
      </g>
      <rect x="6" y="24" width="48" height="3" fill="url(#stoneDark)" />

      {/* Shaft with flutes */}
      <rect x="10" y="27" width="40" height="746" fill="url(#stone)" />
      <g opacity="0.6">
        <line
          x1="16"
          y1="27"
          x2="16"
          y2="773"
          stroke="#2a1830"
          strokeWidth="0.8" />
        
        <line
          x1="22"
          y1="27"
          x2="22"
          y2="773"
          stroke="#2a1830"
          strokeWidth="0.8" />
        
        <line
          x1="30"
          y1="27"
          x2="30"
          y2="773"
          stroke="#2a1830"
          strokeWidth="0.8" />
        
        <line
          x1="38"
          y1="27"
          x2="38"
          y2="773"
          stroke="#2a1830"
          strokeWidth="0.8" />
        
        <line
          x1="44"
          y1="27"
          x2="44"
          y2="773"
          stroke="#2a1830"
          strokeWidth="0.8" />
        
      </g>
      {/* Highlight stripe */}
      <line
        x1="26"
        y1="27"
        x2="26"
        y2="773"
        stroke="#c9a8d4"
        strokeWidth="0.6"
        opacity="0.35" />
      

      {/* Base */}
      <rect x="6" y="773" width="48" height="4" fill="url(#stoneDark)" />
      <rect x="2" y="777" width="56" height="6" fill="url(#stone)" />
      <rect x="0" y="783" width="60" height="6" fill="url(#stoneDark)" />
      <rect x="0" y="789" width="60" height="11" fill="url(#stone)" />
    </svg>);

}
function Sconce() {
  return (
    <div className="relative w-10 h-16">
      {/* Bracket */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-3 h-8 bg-gradient-to-b from-[#7a5828] via-[#3a2510] to-[#1a0c08] rounded-sm shadow-md"></div>
      {/* Bowl */}
      <div
        className="absolute top-6 left-0 right-0 mx-auto w-8 h-3 rounded-b-full"
        style={{
          background:
          'linear-gradient(to bottom, #8a6a32 0%, #4a2f10 80%, #1a0c08 100%)',
          boxShadow:
          'inset 0 1px 0 rgba(255,220,160,0.4), 0 2px 4px rgba(0,0,0,0.6)'
        }}>
      </div>
      {/* Gold rim */}
      <div className="absolute top-6 left-0 right-0 mx-auto w-8 h-0.5 bg-megara-gold/70"></div>

      {/* Flame */}
      <motion.div
        className="absolute left-1/2 -translate-x-1/2 top-0"
        animate={{
          scale: [1, 1.12, 0.95, 1.08, 1],
          rotate: [0, 2, -2, 1, 0]
        }}
        transition={{
          duration: 1.4,
          repeat: Infinity,
          ease: 'easeInOut'
        }}>
        
        <div
          className="w-3 h-5 rounded-full"
          style={{
            background:
            'radial-gradient(ellipse at 50% 70%, rgba(255,210,140,1) 0%, rgba(220,90,140,0.95) 40%, rgba(140,30,90,0.6) 75%, transparent 100%)',
            filter: 'blur(0.5px)',
            boxShadow:
            '0 0 14px rgba(220,90,140,0.7), 0 0 28px rgba(160,40,100,0.45)'
          }}>
        </div>
      </motion.div>
    </div>);

}
function LaurelMedallion() {
  // A simple laurel wreath ring for the back watermark.
  return (
    <svg
      width="540"
      height="540"
      viewBox="0 0 200 200"
      xmlns="http://www.w3.org/2000/svg">
      
      <circle
        cx="100"
        cy="100"
        r="80"
        fill="none"
        stroke="#d4a857"
        strokeWidth="0.6" />
      
      <circle
        cx="100"
        cy="100"
        r="72"
        fill="none"
        stroke="#d4a857"
        strokeWidth="0.4" />
      
      {Array.from({
        length: 24
      }).map((_, i) => {
        const a = i / 24 * Math.PI * 2;
        const x = 100 + Math.cos(a) * 76;
        const y = 100 + Math.sin(a) * 76;
        return (
          <ellipse
            key={i}
            cx={x}
            cy={y}
            rx="5"
            ry="2"
            fill="none"
            stroke="#d4a857"
            strokeWidth="0.5"
            transform={`rotate(${a * 180 / Math.PI + 90} ${x} ${y})`} />);


      })}
      <text
        x="100"
        y="108"
        textAnchor="middle"
        fontFamily="Cinzel, serif"
        fontSize="22"
        fontWeight="700"
        fill="#d4a857"
        letterSpacing="6">
        
        WK
      </text>
    </svg>);

}