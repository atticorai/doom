import React, { Fragment } from 'react';
import { motion } from 'framer-motion';
import { Eye, Download, Link as LinkIcon } from 'lucide-react';
import { Instruction, ScheduleGroup } from './mockData';
interface OpenScrollProps {
  instruction: Instruction;
}
const toneStyles: Record<
  ScheduleGroup['tone'],
  {
    bg: string;
    border: string;
    text: string;
  }> =
{
  lavender: {
    bg: 'bg-[#d4c5e0]',
    border: 'border-[#a586b8]',
    text: 'text-[#3a1f4a]'
  },
  rose: {
    bg: 'bg-[#e0c5cd]',
    border: 'border-[#b8869a]',
    text: 'text-[#4a1f2e]'
  },
  sage: {
    bg: 'bg-[#c5dac7]',
    border: 'border-[#86b896]',
    text: 'text-[#1f4a2e]'
  },
  sand: {
    bg: 'bg-[#e8d9b8]',
    border: 'border-[#b8a486]',
    text: 'text-[#4a3a1f]'
  },
  blush: {
    bg: 'bg-[#e8c5b8]',
    border: 'border-[#b88a6f]',
    text: 'text-[#4a2a1f]'
  }
};
/**
 * OpenScroll — the unfurled document.
 *
 * When the closed scroll is "unfurled", the paper hangs down with the rolled
 * rod visible at top and bottom (since the scroll is being read vertically).
 *
 * Top and bottom show the cylindrical rod the paper is wound around, with
 * cap knobs poking out on the sides. The middle is the unfurled parchment.
 */
export function OpenScroll({ instruction }: OpenScrollProps) {
  return (
    <motion.div
      initial={{
        opacity: 0,
        scaleY: 0.6
      }}
      animate={{
        opacity: 1,
        scaleY: 1
      }}
      exit={{
        opacity: 0,
        scaleY: 0.6
      }}
      transition={{
        duration: 0.45,
        ease: [0.22, 1, 0.36, 1]
      }}
      style={{
        transformOrigin: 'top center'
      }}
      className="w-full max-w-3xl mx-auto mt-4">
      
      {/* TOP ROD — the cylinder the paper unfurls from */}
      <HorizontalRod position="top" />

      {/* PARCHMENT BODY */}
      <div className="relative bg-gradient-to-b from-parchment-light via-parchment to-parchment-dark shadow-[inset_0_0_60px_rgba(120,100,60,0.25),0_8px_20px_rgba(0,0,0,0.4)]">
        {/* Top curl shadow */}
        <div className="absolute top-0 left-0 right-0 h-5 bg-gradient-to-b from-[#7a5828]/30 to-transparent pointer-events-none z-10"></div>
        {/* Bottom curl shadow */}
        <div className="absolute bottom-0 left-0 right-0 h-5 bg-gradient-to-t from-[#7a5828]/30 to-transparent pointer-events-none z-10"></div>
        {/* Side darken (subtle paper sides) */}
        <div className="absolute inset-y-0 left-0 w-1 bg-gradient-to-r from-black/20 to-transparent pointer-events-none"></div>
        <div className="absolute inset-y-0 right-0 w-1 bg-gradient-to-l from-black/20 to-transparent pointer-events-none"></div>

        {/* Vellum noise */}
        <div
          className="absolute inset-0 opacity-[0.04] pointer-events-none"
          style={{
            backgroundImage: 'radial-gradient(#3a2510 1px, transparent 1px)',
            backgroundSize: '5px 5px'
          }}>
        </div>

        <div className="relative z-20 p-6 sm:p-10">
          {/* Doc header */}
          <div className="flex flex-col items-center text-center mb-5 pb-3 border-b border-megara-wine/20">
            <span className="font-cinzel font-bold text-[10px] tracking-[0.3em] text-megara-dark/70 uppercase">
              {instruction.client}
            </span>
            <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-megara-wine tracking-wide mt-1">
              {instruction.client.toUpperCase()}
            </h2>
            <div className="font-cinzel text-[10px] tracking-[0.25em] text-megara-dark/70 uppercase mt-1">
              {instruction.media} Traffic Instructions
            </div>
            <div className="mt-2 w-24 h-px bg-gradient-to-r from-transparent via-megara-gold to-transparent"></div>
          </div>

          {/* Meta */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-10 gap-y-0.5 font-eb text-xs sm:text-sm text-megara-dark mb-3">
            <MetaRow label="Agency" value={instruction.agency} />
            <MetaRow label="Buyer" value={instruction.buyer} accent />
            <MetaRow label="Client" value={instruction.client} accent />
            <MetaRow label="Estimate" value={instruction.estimate} />
            <MetaRow label="Market" value={instruction.market} />
            <MetaRow label="Media" value={instruction.media} accent />
            <MetaRow label="Month" value={instruction.month} accent />
            <MetaRow label="Flight" value={instruction.flight} accent />
            <MetaRow label="Version" value={instruction.version} />
          </div>

          {/* Comments */}
          <div className="font-eb text-xs sm:text-sm text-megara-dark/80 mb-5 leading-relaxed border-l-2 border-megara-gold/60 pl-3 italic">
            <span className="font-semibold not-italic text-megara-dark">
              Comments:{' '}
            </span>
            {instruction.comments}{' '}
            <a
              href={instruction.driveLink}
              className="inline-flex items-center gap-1 text-megara-wine hover:text-megara-magenta underline decoration-dotted underline-offset-2 not-italic">
              
              <LinkIcon className="w-3 h-3" />
              drive link
            </a>
          </div>

          <div className="h-px bg-gradient-to-r from-transparent via-megara-gold to-transparent mb-3"></div>

          {/* Schedule table */}
          <div className="overflow-x-auto">
            <table className="w-full font-eb text-xs sm:text-sm text-megara-dark border-collapse">
              <thead>
                <tr className="text-left text-[9px] sm:text-[10px] tracking-[0.18em] uppercase text-megara-dark/60 font-cinzel font-semibold">
                  <th className="py-1.5 pr-3 w-24">Flight</th>
                  <th className="py-1.5 pr-3">ISCI Code & Title</th>
                  <th className="py-1.5 pr-3 w-12">Dur</th>
                  <th className="py-1.5 pr-3 w-14">Rot%</th>
                  <th className="py-1.5 pr-3 w-28">Schedule</th>
                </tr>
              </thead>
              <tbody>
                {instruction.groups.map((group) => {
                  const tone = toneStyles[group.tone];
                  return (
                    <Fragment key={group.label}>
                      <tr
                        className={`${tone.bg} ${tone.text} border-y ${tone.border}`}>
                        
                        <td
                          colSpan={5}
                          className="py-1 px-2 font-cinzel font-semibold text-[10px] tracking-[0.18em] uppercase">
                          
                          {group.label}
                        </td>
                      </tr>
                      {group.rows.map((row, ri) =>
                      <tr
                        key={`${group.label}-${ri}`}
                        className="border-b border-parchment-shadow/30 hover:bg-megara-gold/15 transition-colors">
                        
                          <td className="py-1 pr-3 px-2 whitespace-nowrap text-megara-dark/80">
                            {row.flight}
                          </td>
                          <td className="py-1 pr-3 font-semibold text-megara-wine">
                            <span className="mr-1">{row.isci}</span>
                            <span className="text-megara-dark/80 font-normal">
                              — {row.title}
                            </span>
                          </td>
                          <td className="py-1 pr-3 whitespace-nowrap">
                            {row.dur}
                          </td>
                          <td className="py-1 pr-3 whitespace-nowrap">
                            {row.rot}
                          </td>
                          <td className="py-1 pr-3 whitespace-nowrap text-megara-dark/80">
                            {row.schedule}
                          </td>
                        </tr>
                      )}
                    </Fragment>);

                })}
              </tbody>
            </table>
          </div>

          {/* Creative files */}
          <div className="mt-6 pt-3 border-t border-megara-wine/20">
            <div className="font-cinzel text-[10px] tracking-[0.22em] uppercase text-megara-dark/70 mb-2">
              Creative Files — click to download
            </div>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 font-eb text-xs sm:text-sm">
              {instruction.creativeFiles.map((cf, i) =>
              <li key={`${cf.isci}-${i}`}>
                  <a
                  href="#"
                  className="text-megara-wine hover:text-megara-magenta underline decoration-dotted underline-offset-2 transition-colors">
                  
                    {cf.isci} — {cf.title}
                  </a>
                </li>
              )}
            </ul>
          </div>

          {/* Actions */}
          <div className="mt-6 pt-3 border-t border-megara-wine/20 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="font-cormorant italic text-megara-dark/60 text-xs sm:text-sm">
              Filed under {instruction.month} · Estimate {instruction.estimate}{' '}
              · {instruction.version}
            </div>
            <div className="flex gap-2">
              <button className="flex items-center gap-1.5 px-3 py-1.5 bg-transparent border border-megara-wine/40 text-megara-wine font-cinzel text-xs font-semibold rounded hover:bg-megara-wine hover:text-parchment transition-all duration-200 group/btn">
                <Eye className="w-3.5 h-3.5 group-hover/btn:scale-110 transition-transform" />
                <span>View</span>
              </button>
              <button className="flex items-center gap-1.5 px-3 py-1.5 bg-megara-wine border border-megara-gold/50 text-parchment font-cinzel text-xs font-semibold rounded hover:bg-megara-magenta transition-all duration-200 group/btn">
                <Download className="w-3.5 h-3.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                <span>Download</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM ROD */}
      <HorizontalRod position="bottom" />
    </motion.div>);

}
function MetaRow({
  label,
  value,
  accent = false




}: {label: string;value: string;accent?: boolean;}) {
  return (
    <div className="flex gap-3">
      <span className="font-cinzel text-[10px] tracking-[0.15em] uppercase text-megara-dark/70 font-semibold w-16 shrink-0 pt-0.5">
        {label}:
      </span>
      <span
        className={`font-eb ${accent ? 'text-megara-wine font-semibold' : 'text-megara-dark'}`}>
        
        {value}
      </span>
    </div>);

}
function HorizontalRod({ position }: {position: 'top' | 'bottom';}) {
  return (
    <div
      className={`relative h-6 z-30 ${position === 'top' ? '-mb-1' : '-mt-1'}`}>
      
      {/* Rod body — cylinder shading top→bottom */}
      <div
        className="absolute inset-x-0 inset-y-0 mx-[-12px]"
        style={{
          background:
          'linear-gradient(to bottom, #6a4828 0%, #b89770 25%, #f1dcb0 50%, #b89770 75%, #5a3a20 100%)',
          boxShadow:
          'inset 0 1px 0 rgba(255,220,170,0.4), inset 0 -1px 0 rgba(0,0,0,0.4), 0 4px 10px rgba(0,0,0,0.4)'
        }}>
      </div>
      {/* Gold trim ribbons */}
      <div
        className={`absolute inset-x-0 mx-[-12px] h-1 ${position === 'top' ? 'bottom-0' : 'top-0'} bg-gradient-to-b from-megara-magenta via-megara-wine to-[#4a0f25] shadow-[inset_0_1px_0_rgba(212,168,87,0.6)]`}>
      </div>
      {/* End knobs */}
      <div
        className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full"
        style={{
          background:
          'radial-gradient(ellipse at 30% 30%, #f3dcae 0%, #c9a675 35%, #8a5e30 75%, #4a2f10 100%)',
          boxShadow: '0 2px 4px rgba(0,0,0,0.5)'
        }}>
        
        <div className="absolute inset-[3px] rounded-full border border-megara-gold/70"></div>
      </div>
      <div
        className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full"
        style={{
          background:
          'radial-gradient(ellipse at 30% 30%, #f3dcae 0%, #c9a675 35%, #8a5e30 75%, #4a2f10 100%)',
          boxShadow: '0 2px 4px rgba(0,0,0,0.5)'
        }}>
        
        <div className="absolute inset-[3px] rounded-full border border-megara-gold/70"></div>
      </div>
    </div>);

}