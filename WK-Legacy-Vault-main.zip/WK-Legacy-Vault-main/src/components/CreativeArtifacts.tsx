import React, { useId } from 'react';
import { motion } from 'framer-motion';
/* ============================================================== */
/* Shared button wrapper                                            */
/* ============================================================== */
function ArtifactButton({
  children,
  width,
  rotation = 0,
  onClick,
  title






}: {children: React.ReactNode;width: number;rotation?: number;onClick?: () => void;title?: string;}) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={{
        y: -4,
        scale: 1.04
      }}
      whileTap={{
        scale: 0.97
      }}
      transition={{
        type: 'spring',
        stiffness: 320,
        damping: 22
      }}
      style={{
        width,
        rotate: `${rotation}deg`
      }}
      className="relative group focus:outline-none flex flex-col items-center"
      title={title}>
      
      {children}
    </motion.button>);

}
/* ============================================================== */
/* 1. APOTHECARY BOTTLE — refined glass bottle, less cartoonish     */
/* ============================================================== */
export function ApothecaryBottle({
  title,
  year,
  category,
  accent = '#5a2a78',
  rotation = 0,
  onClick







}: {title: string;year: number;category: string;accent?: string;rotation?: number;onClick?: () => void;}) {
  const uid = useId().replace(/[:]/g, '');
  const bottlePath =
  'M 38 26 L 38 44 Q 38 49 35 52 Q 22 60 22 76 L 22 152 Q 22 162 32 162 L 68 162 Q 78 162 78 152 L 78 76 Q 78 60 65 52 Q 62 49 62 44 L 62 26 Z';
  const liquidPath =
  'M 25 90 Q 25 65 36 58 L 64 58 Q 75 65 75 90 L 75 150 Q 75 158 68 158 L 32 158 Q 25 158 25 150 Z';
  const deep = darken(accent, 0.45);
  const dim = darken(accent, 0.75);
  return (
    <ArtifactButton
      width={100}
      rotation={rotation}
      onClick={onClick}
      title={`${title} · ${year}`}>
      
      <div
        className="absolute -inset-3 rounded-full opacity-0 group-hover:opacity-80 transition-opacity duration-300 pointer-events-none blur-2xl"
        style={{
          background: `radial-gradient(ellipse 55% 65% at 50% 60%, ${accent}88 0%, ${accent}22 60%, transparent 85%)`
        }}>
      </div>

      <svg
        viewBox="0 0 100 180"
        width="100"
        height="180"
        className="relative"
        style={{
          filter: 'drop-shadow(0 10px 14px rgba(0,0,0,0.75))'
        }}>
        
        <defs>
          <linearGradient id={`body-${uid}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="rgba(0,0,0,0.85)" />
            <stop offset="22%" stopColor={dim} stopOpacity="0.7" />
            <stop offset="50%" stopColor={accent} stopOpacity="0.45" />
            <stop offset="78%" stopColor={dim} stopOpacity="0.78" />
            <stop offset="100%" stopColor="rgba(0,0,0,0.95)" />
          </linearGradient>
          <linearGradient id={`liquid-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={accent} stopOpacity="0.85" />
            <stop offset="55%" stopColor={deep} stopOpacity="0.95" />
            <stop offset="100%" stopColor="#04020a" stopOpacity="1" />
          </linearGradient>
          <linearGradient id={`liquid-h-${uid}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="rgba(0,0,0,0.55)" />
            <stop offset="20%" stopColor="rgba(0,0,0,0)" />
            <stop offset="80%" stopColor="rgba(0,0,0,0)" />
            <stop offset="100%" stopColor="rgba(0,0,0,0.55)" />
          </linearGradient>
          <linearGradient id={`cork-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#d2a45c" />
            <stop offset="35%" stopColor="#a87434" />
            <stop offset="100%" stopColor="#5a3a14" />
          </linearGradient>
          <linearGradient id={`wax-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#a82a40" />
            <stop offset="55%" stopColor="#6a1224" />
            <stop offset="100%" stopColor="#380612" />
          </linearGradient>
          <radialGradient id={`punt-${uid}`} cx="0.5" cy="1" r="0.6">
            <stop offset="0%" stopColor="rgba(0,0,0,0.8)" />
            <stop offset="100%" stopColor="rgba(0,0,0,0)" />
          </radialGradient>
          <linearGradient id={`label-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#efe1b8" />
            <stop offset="50%" stopColor="#e3d09a" />
            <stop offset="100%" stopColor="#c9b272" />
          </linearGradient>
          <linearGradient id={`label-curve-${uid}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="rgba(40,25,0,0.45)" />
            <stop offset="20%" stopColor="rgba(40,25,0,0)" />
            <stop offset="80%" stopColor="rgba(40,25,0,0)" />
            <stop offset="100%" stopColor="rgba(40,25,0,0.45)" />
          </linearGradient>
        </defs>

        <ellipse cx="50" cy="168" rx="32" ry="4" fill="rgba(0,0,0,0.6)" />

        <path d={bottlePath} fill={`url(#body-${uid})`} />

        <path d={liquidPath} fill={`url(#liquid-${uid})`} />
        <path d={liquidPath} fill={`url(#liquid-h-${uid})`} />
        <ellipse cx="50" cy="158" rx="22" ry="6" fill={`url(#punt-${uid})`} />
        <path
          d="M 26 60 Q 50 56 74 60"
          stroke="rgba(255,255,255,0.22)"
          strokeWidth="0.8"
          fill="none" />
        
        <ellipse
          cx="50"
          cy="60"
          rx="22"
          ry="1.6"
          fill="rgba(255,255,255,0.08)" />
        

        <path
          d="M 30 70 Q 28 110 30 150"
          stroke="rgba(255,255,255,0.7)"
          strokeWidth="2.2"
          fill="none"
          strokeLinecap="round" />
        
        <path
          d="M 31 70 Q 29 110 31 150"
          stroke="rgba(255,255,255,0.35)"
          strokeWidth="4"
          fill="none"
          strokeLinecap="round"
          opacity="0.6" />
        
        <path
          d="M 34 80 Q 33 110 34 138"
          stroke="rgba(255,255,255,0.18)"
          strokeWidth="1"
          fill="none"
          strokeLinecap="round" />
        
        <path
          d="M 70 76 Q 71 110 70 144"
          stroke="rgba(255,255,255,0.28)"
          strokeWidth="1.4"
          fill="none"
          strokeLinecap="round" />
        
        <path
          d={bottlePath}
          fill="none"
          stroke="rgba(0,0,0,0.85)"
          strokeWidth="0.7" />
        

        <rect x="38" y="42" width="24" height="2" fill="rgba(0,0,0,0.5)" />
        <rect
          x="38"
          y="44"
          width="24"
          height="1"
          fill="rgba(255,255,255,0.18)" />
        

        <g>
          <rect
            x="36"
            y="14"
            width="28"
            height="16"
            rx="1.5"
            fill={`url(#cork-${uid})`}
            stroke="#2a1808"
            strokeWidth="0.5" />
          
          <path
            d="M 39 17 Q 45 22 40 28"
            stroke="rgba(0,0,0,0.35)"
            strokeWidth="0.4"
            fill="none" />
          
          <path
            d="M 47 16 Q 52 24 48 29"
            stroke="rgba(0,0,0,0.3)"
            strokeWidth="0.4"
            fill="none" />
          
          <path
            d="M 56 18 Q 60 23 57 28"
            stroke="rgba(0,0,0,0.3)"
            strokeWidth="0.4"
            fill="none" />
          
          <circle cx="42" cy="20" r="0.5" fill="rgba(0,0,0,0.4)" />
          <circle cx="50" cy="22" r="0.4" fill="rgba(0,0,0,0.4)" />
          <circle cx="58" cy="20" r="0.5" fill="rgba(0,0,0,0.4)" />
          <circle cx="46" cy="25" r="0.3" fill="rgba(0,0,0,0.4)" />
          <circle cx="55" cy="26" r="0.4" fill="rgba(0,0,0,0.4)" />
          <rect
            x="36"
            y="14"
            width="28"
            height="1.2"
            fill="rgba(255,235,180,0.55)" />
          
          <rect x="36" y="28" width="28" height="1.6" fill="rgba(0,0,0,0.55)" />
        </g>

        <g>
          <path
            d="M 32 24 Q 33 32 35 30 Q 37 38 40 32 Q 42 42 45 33 Q 48 46 51 34 Q 54 40 57 32 Q 60 38 62 30 Q 65 35 67 26 L 68 18 Q 60 14 50 14 Q 38 14 32 18 Z"
            fill={`url(#wax-${uid})`}
            stroke="rgba(0,0,0,0.6)"
            strokeWidth="0.4" />
          
          <path
            d="M 36 18 Q 48 14 60 18"
            stroke="rgba(255,180,180,0.55)"
            strokeWidth="0.8"
            fill="none"
            strokeLinecap="round" />
          
          <ellipse
            cx="44"
            cy="19"
            rx="3"
            ry="0.8"
            fill="rgba(255,200,200,0.3)" />
          
        </g>

        <g transform="translate(20 92)">
          <path
            d="M 0 0 Q 30 -1.5 60 0 L 60 42 Q 30 43.5 0 42 Z"
            fill={`url(#label-${uid})`}
            stroke="#8a6e3a"
            strokeWidth="0.5" />
          
          <path
            d="M 0 0 Q 30 -1.5 60 0 L 60 42 Q 30 43.5 0 42 Z"
            fill={`url(#label-curve-${uid})`} />
          
          <ellipse cx="12" cy="14" rx="6" ry="3" fill="rgba(120,85,30,0.15)" />
          <ellipse cx="48" cy="32" rx="7" ry="3" fill="rgba(120,85,30,0.12)" />
          <line
            x1="5"
            y1="4"
            x2="55"
            y2="4"
            stroke="#5a3a14"
            strokeWidth="0.4" />
          
          <line
            x1="5"
            y1="5.6"
            x2="55"
            y2="5.6"
            stroke="#5a3a14"
            strokeWidth="0.25" />
          
          <line
            x1="5"
            y1="38"
            x2="55"
            y2="38"
            stroke="#5a3a14"
            strokeWidth="0.4" />
          
          <line
            x1="5"
            y1="36.4"
            x2="55"
            y2="36.4"
            stroke="#5a3a14"
            strokeWidth="0.25" />
          
          <text
            x="30"
            y="11"
            textAnchor="middle"
            fontFamily="Cinzel, serif"
            fontSize="3.5"
            fontWeight="700"
            fill="#4a2f10"
            letterSpacing="1"
            style={{
              textTransform: 'uppercase'
            }}>
            
            Atticor · Creative
          </text>
          <text
            x="30"
            y="20"
            textAnchor="middle"
            fontFamily="Cinzel, serif"
            fontSize={title.length > 14 ? 5.5 : 7}
            fontWeight="700"
            fill="#2a1808"
            letterSpacing="0.6"
            style={{
              textTransform: 'uppercase'
            }}>
            
            {title.length > 18 ? title.slice(0, 17) + '…' : title}
          </text>
          <line
            x1="20"
            y1="23"
            x2="40"
            y2="23"
            stroke="#5a3a14"
            strokeWidth="0.35" />
          
          <text
            x="30"
            y="29"
            textAnchor="middle"
            fontFamily="Georgia, serif"
            fontStyle="italic"
            fontSize="5"
            fill="#5a3a18">
            
            {category}
          </text>
          <text
            x="30"
            y="35"
            textAnchor="middle"
            fontFamily="Cinzel, serif"
            fontSize="5"
            fontWeight="600"
            fill="#3a2510"
            letterSpacing="1">
            
            {year}
          </text>
        </g>

        <ellipse cx="50" cy="50" rx="13" ry="1.6" fill="#3a2010" />
        <path
          d="M 37 50 Q 50 47 63 50"
          stroke="rgba(180,140,80,0.4)"
          strokeWidth="0.4"
          fill="none" />
        
      </svg>
    </ArtifactButton>);

}
function darken(hex: string, factor: number): string {
  const m = hex.match(/^#?([a-f0-9]{6})$/i);
  if (!m) return hex;
  const num = parseInt(m[1], 16);
  const r = Math.max(0, Math.floor((num >> 16 & 0xff) * factor));
  const g = Math.max(0, Math.floor((num >> 8 & 0xff) * factor));
  const b = Math.max(0, Math.floor((num & 0xff) * factor));
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('')}`;
}
/* ============================================================== */
/* 2. CRT TV — vintage television (kept compact for the wall)        */
/* ============================================================== */
export function CRT({
  title,
  year,
  category,
  rotation = 0,
  onClick






}: {title: string;year: number;category: string;rotation?: number;onClick?: () => void;}) {
  return (
    <ArtifactButton
      width={150}
      rotation={rotation}
      onClick={onClick}
      title={`${title} · ${year}`}>
      
      <div
        className="relative w-full"
        style={{
          height: 120
        }}>
        
        {/* TV body */}
        <div
          className="absolute inset-0 rounded-md"
          style={{
            background:
            'linear-gradient(180deg, #4a3a2a 0%, #2a1f14 60%, #1a120a 100%)',
            boxShadow:
            'inset 0 1px 0 rgba(255,220,170,0.25), inset 0 -2px 4px rgba(0,0,0,0.7), 0 8px 14px rgba(0,0,0,0.6)',
            border: '1px solid #0a0604'
          }}>
        </div>

        {/* Screen bezel */}
        <div
          className="absolute"
          style={{
            left: 8,
            top: 8,
            right: 32,
            bottom: 8,
            borderRadius: 8
          }}>
          
          <div
            className="absolute inset-0 rounded-lg"
            style={{
              background: '#0a0606',
              boxShadow:
              'inset 0 0 12px rgba(0,0,0,0.95), inset 0 0 2px rgba(0,0,0,1)'
            }}>
          </div>
          <div
            className="absolute rounded-md overflow-hidden"
            style={{
              left: 5,
              top: 5,
              right: 5,
              bottom: 5,
              background:
              'radial-gradient(ellipse at 50% 50%, #1a3018 0%, #0a1808 70%, #050a04 100%)',
              boxShadow: 'inset 0 0 16px rgba(0,0,0,0.85)'
            }}>
            
            {/* Scan lines */}
            <div
              className="absolute inset-0 opacity-40 pointer-events-none"
              style={{
                backgroundImage:
                'repeating-linear-gradient(0deg, transparent 0px, transparent 1px, rgba(0,0,0,0.4) 2px)'
              }}>
            </div>
            {/* Title on screen */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-1.5">
              <div
                className="font-cinzel font-bold uppercase leading-tight"
                style={{
                  fontSize: title.length > 10 ? 7 : 9,
                  letterSpacing: '0.1em',
                  color: '#9af098',
                  textShadow:
                  '0 0 4px rgba(140,255,140,0.9), 0 0 8px rgba(140,255,140,0.45)'
                }}>
                
                {title}
              </div>
              <div
                className="mt-0.5 font-eb"
                style={{
                  fontSize: 6,
                  color: 'rgba(154,240,152,0.65)',
                  letterSpacing: '0.18em'
                }}>
                
                {category} · {year}
              </div>
            </div>
            {/* Specular highlight on glass */}
            <div
              className="absolute top-1 left-1 right-6 h-3 rounded-full opacity-25 pointer-events-none"
              style={{
                background:
                'linear-gradient(180deg, rgba(255,255,255,0.5), transparent)'
              }}>
            </div>
          </div>
        </div>

        {/* Right panel — knobs */}
        <div
          className="absolute"
          style={{
            right: 6,
            top: 12,
            width: 20
          }}>
          
          <div
            className="w-full h-3 rounded-full"
            style={{
              background:
              'radial-gradient(circle at 35% 30%, #e9c97a 0%, #8a5e1f 60%, #2a1408 100%)',
              boxShadow: '0 1px 1px rgba(0,0,0,0.6)'
            }}>
          </div>
          <div
            className="mt-2 w-full h-3 rounded-full"
            style={{
              background:
              'radial-gradient(circle at 35% 30%, #e9c97a 0%, #8a5e1f 60%, #2a1408 100%)',
              boxShadow: '0 1px 1px rgba(0,0,0,0.6)'
            }}>
          </div>
          <div className="mt-3 w-full h-2 rounded-sm bg-black/60"></div>
          <span className="absolute -top-1 -right-1 block w-1 h-1 rounded-full bg-red-500/90 shadow-[0_0_3px_rgba(255,60,60,0.85)]"></span>
        </div>
      </div>
    </ArtifactButton>);

}
/* ============================================================== */
/* 3. SCRYING ORB — crystal sphere on a velvet pedestal              */
/* ============================================================== */
export function ScryingOrb({
  title,
  year,
  category,
  accent = '#a85ad8',
  rotation = 0,
  onClick







}: {title: string;year: number;category: string;accent?: string;rotation?: number;onClick?: () => void;}) {
  return (
    <ArtifactButton
      width={110}
      rotation={rotation}
      onClick={onClick}
      title={`${title} · ${year}`}>
      
      <div
        className="relative"
        style={{
          width: 110,
          height: 140
        }}>
        
        {/* Outer aura */}
        <div
          className="absolute -inset-2 rounded-full opacity-60 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none blur-xl"
          style={{
            background: `radial-gradient(ellipse 70% 60% at 50% 40%, ${accent}aa 0%, ${accent}33 50%, transparent 80%)`
          }}>
        </div>

        <svg
          viewBox="0 0 110 140"
          width="110"
          height="140"
          className="relative">
          
          <defs>
            <radialGradient
              id={`orb-${title}-${year}`}
              cx="0.35"
              cy="0.3"
              r="0.7">
              
              <stop offset="0%" stopColor="#fff9e6" stopOpacity="0.9" />
              <stop offset="25%" stopColor={accent} stopOpacity="0.85" />
              <stop offset="70%" stopColor={accent} stopOpacity="0.6" />
              <stop offset="100%" stopColor="#0a0410" stopOpacity="0.95" />
            </radialGradient>
            <radialGradient
              id={`orb-inner-${title}-${year}`}
              cx="0.5"
              cy="0.5"
              r="0.55">
              
              <stop offset="0%" stopColor="rgba(255,255,255,0.0)" />
              <stop offset="45%" stopColor="rgba(255,255,255,0.0)" />
              <stop offset="75%" stopColor="rgba(0,0,0,0.4)" />
              <stop offset="100%" stopColor="rgba(0,0,0,0.7)" />
            </radialGradient>
            <linearGradient
              id={`vel-${title}-${year}`}
              x1="0"
              y1="0"
              x2="0"
              y2="1">
              
              <stop offset="0%" stopColor="#5a1d3a" />
              <stop offset="60%" stopColor="#2a0810" />
              <stop offset="100%" stopColor="#0a0204" />
            </linearGradient>
          </defs>

          {/* Pedestal */}
          <ellipse cx="55" cy="125" rx="32" ry="4" fill="rgba(0,0,0,0.7)" />
          <path
            d="M 30 120 L 80 120 L 75 105 L 35 105 Z"
            fill={`url(#vel-${title}-${year})`}
            stroke="rgba(0,0,0,0.7)"
            strokeWidth="0.6" />
          
          <ellipse
            cx="55"
            cy="105"
            rx="20"
            ry="3.5"
            fill="#3a1020"
            stroke="#5a1d3a"
            strokeWidth="0.4" />
          
          {/* Gold trim */}
          <ellipse
            cx="55"
            cy="105"
            rx="20"
            ry="1.4"
            fill="#c79a3e"
            opacity="0.7" />
          

          {/* Orb */}
          <circle
            cx="55"
            cy="65"
            r="38"
            fill={`url(#orb-${title}-${year})`}
            stroke="rgba(0,0,0,0.5)"
            strokeWidth="0.6" />
          
          {/* Inner shadow ring */}
          <circle
            cx="55"
            cy="65"
            r="38"
            fill={`url(#orb-inner-${title}-${year})`} />
          

          {/* Title text faintly visible inside */}
          <text
            x="55"
            y="62"
            textAnchor="middle"
            fontFamily="Cinzel, serif"
            fontSize={title.length > 10 ? 5.5 : 7}
            fontWeight="700"
            fill="rgba(255,245,214,0.92)"
            letterSpacing="0.5"
            style={{
              textTransform: 'uppercase',
              filter: 'drop-shadow(0 0 4px rgba(255,235,180,0.6))'
            }}>
            
            {title.length > 14 ? title.slice(0, 13) + '…' : title}
          </text>
          <text
            x="55"
            y="74"
            textAnchor="middle"
            fontFamily="Georgia, serif"
            fontStyle="italic"
            fontSize="5.5"
            fill="rgba(255,245,214,0.7)">
            
            {category} · {year}
          </text>

          {/* Specular highlight */}
          <ellipse
            cx="42"
            cy="48"
            rx="11"
            ry="6"
            fill="rgba(255,255,255,0.55)"
            transform="rotate(-30 42 48)" />
          
          <ellipse
            cx="38"
            cy="44"
            rx="3"
            ry="2"
            fill="rgba(255,255,255,0.85)" />
          

          {/* Bottom catch-light */}
          <ellipse
            cx="55"
            cy="92"
            rx="22"
            ry="3"
            fill="rgba(255,255,255,0.12)" />
          
        </svg>
      </div>
    </ArtifactButton>);

}
/* ============================================================== */
/* 4. POSTAGE STAMP — perforated tile in a stamp album              */
/* ============================================================== */
export function PostageStamp({
  title,
  year,
  category,
  accent = '#7a3fa0',
  rotation = 0,
  onClick







}: {title: string;year: number;category: string;accent?: string;rotation?: number;onClick?: () => void;}) {
  // Build a perforated stamp shape using a polygon with small bumps
  const w = 86;
  const h = 102;
  const teeth = 8;
  return (
    <ArtifactButton
      width={w}
      rotation={rotation}
      onClick={onClick}
      title={`${title} · ${year}`}>
      
      <svg
        viewBox={`0 0 ${w} ${h}`}
        width={w}
        height={h}
        className="drop-shadow-[0_3px_6px_rgba(0,0,0,0.6)]">
        
        <defs>
          <linearGradient
            id={`stamp-${title}-${year}`}
            x1="0"
            y1="0"
            x2="0"
            y2="1">
            
            <stop offset="0%" stopColor="#fff5d6" />
            <stop offset="40%" stopColor="#f3e5c0" />
            <stop offset="100%" stopColor="#d8c490" />
          </linearGradient>
          <linearGradient
            id={`stamp-art-${title}-${year}`}
            x1="0"
            y1="0"
            x2="1"
            y2="1">
            
            <stop offset="0%" stopColor={accent} stopOpacity="0.95" />
            <stop offset="100%" stopColor="#0a0410" stopOpacity="0.9" />
          </linearGradient>
        </defs>

        {/* Stamp body (perforated edges via mask of small circles) */}
        <mask id={`mask-${title}-${year}`}>
          <rect x="0" y="0" width={w} height={h} fill="white" />
          {/* Top perforations */}
          {Array.from({
            length: teeth + 1
          }).map((_, i) =>
          <circle
            key={`pt-${i}`}
            cx={w / teeth * i}
            cy={0}
            r={3.4}
            fill="black" />

          )}
          {/* Bottom */}
          {Array.from({
            length: teeth + 1
          }).map((_, i) =>
          <circle
            key={`pb-${i}`}
            cx={w / teeth * i}
            cy={h}
            r={3.4}
            fill="black" />

          )}
          {/* Left */}
          {Array.from({
            length: Math.round(teeth * (h / w)) + 1
          }).map((_, i) =>
          <circle
            key={`pl-${i}`}
            cx={0}
            cy={h / (teeth * (h / w)) * i}
            r={3.4}
            fill="black" />

          )}
          {/* Right */}
          {Array.from({
            length: Math.round(teeth * (h / w)) + 1
          }).map((_, i) =>
          <circle
            key={`pr-${i}`}
            cx={w}
            cy={h / (teeth * (h / w)) * i}
            r={3.4}
            fill="black" />

          )}
        </mask>

        <g mask={`url(#mask-${title}-${year})`}>
          {/* Outer paper */}
          <rect
            x="0"
            y="0"
            width={w}
            height={h}
            fill={`url(#stamp-${title}-${year})`} />
          
          {/* Inner frame */}
          <rect
            x="5"
            y="5"
            width={w - 10}
            height={h - 10}
            fill="none"
            stroke="rgba(90,60,20,0.5)"
            strokeWidth="0.5" />
          
          {/* Country/agency band — top */}
          <rect
            x="6"
            y="6"
            width={w - 12}
            height={9}
            fill="rgba(90,60,20,0.1)" />
          
          <text
            x={w / 2}
            y="13"
            textAnchor="middle"
            fontFamily="Cinzel, serif"
            fontSize="5"
            fontWeight="700"
            fill="#3a2510"
            letterSpacing="0.6"
            style={{
              textTransform: 'uppercase'
            }}>
            
            ATTICOR · CREATIVE
          </text>

          {/* Art area */}
          <rect
            x="9"
            y="18"
            width={w - 18}
            height={50}
            fill={`url(#stamp-art-${title}-${year})`}
            stroke="rgba(60,40,10,0.6)"
            strokeWidth="0.5" />
          
          {/* Subject silhouette */}
          <ellipse cx={w / 2} cy={52} rx={14} ry={9} fill="rgba(0,0,0,0.35)" />
          <ellipse cx={w / 2} cy={36} rx={9} ry={11} fill="rgba(0,0,0,0.35)" />

          {/* Title underneath the art */}
          <text
            x={w / 2}
            y={78}
            textAnchor="middle"
            fontFamily="Cinzel, serif"
            fontSize={title.length > 10 ? 5.5 : 7}
            fontWeight="700"
            fill="#3a2510"
            letterSpacing="0.4"
            style={{
              textTransform: 'uppercase'
            }}>
            
            {title.length > 14 ? title.slice(0, 13) + '…' : title}
          </text>

          {/* Year corner */}
          <rect
            x={w - 22}
            y={h - 17}
            width={16}
            height={10}
            fill="rgba(90,60,20,0.18)" />
          
          <text
            x={w - 14}
            y={h - 10}
            textAnchor="middle"
            fontFamily="Cinzel, serif"
            fontSize="5.5"
            fontWeight="700"
            fill="#3a2510"
            letterSpacing="0.3">
            
            {year}
          </text>
          {/* Category corner */}
          <text
            x={8}
            y={h - 10}
            fontFamily="Georgia, serif"
            fontStyle="italic"
            fontSize="5"
            fill="#5a3a18">
            
            {category}
          </text>
        </g>
      </svg>
    </ArtifactButton>);

}