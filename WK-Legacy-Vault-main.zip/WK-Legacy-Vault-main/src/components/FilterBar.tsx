import React from 'react';
import { Scroll, Search, ChevronDown } from 'lucide-react';
export function FilterBar() {
  return (
    <div className="w-full max-w-6xl mx-auto mt-8 mb-12">
      <div className="bg-megara-plum/40 backdrop-blur-md border border-megara-gold/20 rounded-lg p-4 flex flex-col lg:flex-row items-center justify-between gap-4 shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
        {/* Archive Label */}
        <div className="flex items-center gap-3 text-megara-gold w-full lg:w-auto">
          <Scroll className="w-5 h-5" />
          <span className="font-cinzel font-semibold tracking-wide">
            Archive (1,402)
          </span>
        </div>

        {/* Filters & Search */}
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="relative group w-full sm:w-32">
              <select className="w-full appearance-none bg-megara-dark/60 border border-megara-lavender/20 text-megara-lavender font-eb py-2 pl-3 pr-8 rounded focus:outline-none focus:border-megara-gold/50 transition-colors cursor-pointer">
                <option>All Years</option>
                <option>2023</option>
                <option>2022</option>
                <option>2021</option>
                <option>Older</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-megara-lavender/50 pointer-events-none group-hover:text-megara-gold transition-colors" />
            </div>

            <div className="relative group w-full sm:w-36">
              <select className="w-full appearance-none bg-megara-dark/60 border border-megara-lavender/20 text-megara-lavender font-eb py-2 pl-3 pr-8 rounded focus:outline-none focus:border-megara-gold/50 transition-colors cursor-pointer">
                <option>All Markets</option>
                <option>US National</option>
                <option>EMEA</option>
                <option>APAC</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-megara-lavender/50 pointer-events-none group-hover:text-megara-gold transition-colors" />
            </div>

            <div className="relative group w-full sm:w-36">
              <select className="w-full appearance-none bg-megara-dark/60 border border-megara-lavender/20 text-megara-lavender font-eb py-2 pl-3 pr-8 rounded focus:outline-none focus:border-megara-gold/50 transition-colors cursor-pointer">
                <option>All Media</option>
                <option>TV Broadcast</option>
                <option>Digital</option>
                <option>OOH</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-megara-lavender/50 pointer-events-none group-hover:text-megara-gold transition-colors" />
            </div>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-megara-lavender/50" />
            <input
              type="text"
              placeholder="Search ISCI, name, etc..."
              className="w-full bg-megara-dark/60 border border-megara-lavender/20 text-megara-lavender font-eb py-2 pl-9 pr-4 rounded focus:outline-none focus:border-megara-gold/50 placeholder:text-megara-lavender/30 transition-colors" />
            
          </div>
        </div>
      </div>
    </div>);

}