import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { VaultHeader, VaultTab } from './VaultHeader';
import { FilterBar } from './FilterBar';
import { InstructionScroll } from './InstructionScroll';
import { CreativeVault } from './CreativeVault';
import { VaultAtmosphere } from './VaultAtmosphere';
import { mockInstructions, Instruction } from './mockData';
const MONTH_ORDER = ['May', 'June', 'July', 'August'];
const MEDIA_ORDER = ['TV', 'Radio', 'Digital', 'OOH'];
const MARKETS = [
'Huntsville',
'Birmingham',
'Mobile',
'Knoxville',
'Dothan',
'Chattanooga',
'Montgomery',
'Atlanta'];

export function VaultPage() {
  const [activeTab, setActiveTab] = useState<VaultTab>('instructions');
  // Generate a varied set of instructions across Month → Media → Market
  const allInstructions: Instruction[] = useMemo(() => {
    const out: Instruction[] = [];
    let i = 0;
    for (const month of MONTH_ORDER) {
      for (const media of MEDIA_ORDER) {
        const count = media === 'TV' ? 14 : 2 + i % 3; // TV gets 14 per month
        for (let m = 0; m < count; m++) {
          const base = mockInstructions[(i + m) % mockInstructions.length];
          out.push({
            ...base,
            id: `gen-${month}-${media}-${m}`,
            month,
            media,
            market: MARKETS[(i * 3 + m) % MARKETS.length],
            rotation: ((i + m) % 5 - 2) * 0.15
          });
        }
        i++;
      }
    }
    return out;
  }, []);
  // Group: Month → Media → Instructions[]
  const grouped = useMemo(() => {
    const map: Record<string, Record<string, Instruction[]>> = {};
    for (const ins of allInstructions) {
      if (!map[ins.month]) map[ins.month] = {};
      if (!map[ins.month][ins.media]) map[ins.month][ins.media] = [];
      map[ins.month][ins.media].push(ins);
    }
    return map;
  }, [allInstructions]);
  const visibleMonths = MONTH_ORDER.filter((m) => grouped[m]);
  return (
    <div
      className="min-h-screen w-full relative overflow-hidden selection:bg-megara-wine selection:text-parchment"
      style={{
        background:
        'radial-gradient(ellipse at center top, #4a1858 0%, #2a0f2e 35%, #1a0a1f 75%, #0d0512 100%)'
      }}>
      
      <VaultAtmosphere />

      <div className="relative z-10 h-screen overflow-y-auto">
        <div className="px-6 sm:px-16 lg:px-36 pb-24">
          <VaultHeader activeTab={activeTab} onTabChange={setActiveTab} />
          <FilterBar />

          <AnimatePresence mode="wait">
            {activeTab === 'instructions' ?
            <motion.div
              key="instructions"
              initial={{
                opacity: 0,
                y: 20
              }}
              animate={{
                opacity: 1,
                y: 0
              }}
              exit={{
                opacity: 0,
                y: -20
              }}
              transition={{
                duration: 0.4
              }}
              className="mt-8 pb-32">
              
                <SectionBanner
                title="The Archive"
                subtitle="A vault of every traffic instruction we've ever sent — wax-sealed, filed, and waiting." />
              

                <div className="flex flex-col gap-20 mt-14">
                  {visibleMonths.map((month) => {
                  const byMedia = grouped[month];
                  const visibleMedia = MEDIA_ORDER.filter((m) => byMedia[m]);
                  const monthTotal = Object.values(byMedia).flat().length;
                  return (
                    <section key={month}>
                        <MonthBanner label={month} count={monthTotal} />
                        <div className="flex flex-col gap-14 mt-10">
                          {visibleMedia.map((media) => {
                          const instructions = byMedia[media];
                          return (
                            <div key={media}>
                                <MediaBanner
                                media={media}
                                count={instructions.length} />
                              
                                <div className="flex flex-wrap gap-x-3 gap-y-3 mt-4 justify-start">
                                  {instructions.map((instruction, index) =>
                                <InstructionScroll
                                  key={instruction.id}
                                  instruction={instruction}
                                  index={index} />

                                )}
                                </div>
                              </div>);

                        })}
                        </div>
                      </section>);

                })}
                </div>

                <div className="mt-20 text-center">
                  <div className="inline-flex items-center gap-4 font-cormorant italic text-megara-lavender/50 text-sm">
                    <span className="h-px w-16 bg-megara-gold/30"></span>
                    end of the underworld archive — for now
                    <span className="h-px w-16 bg-megara-gold/30"></span>
                  </div>
                </div>
              </motion.div> :

            <motion.div
              key="creative"
              initial={{
                opacity: 0,
                y: 20
              }}
              animate={{
                opacity: 1,
                y: 0
              }}
              exit={{
                opacity: 0,
                y: -20
              }}
              transition={{
                duration: 0.4
              }}
              className="mt-12 pb-32">
              
                <SectionBanner
                title="The Apothecary"
                subtitle="Every TV spot and radio cut — bottled, labeled, shelved by the year it aired." />
              
                <div className="mt-10">
                  <CreativeVault />
                </div>
              </motion.div>
            }
          </AnimatePresence>
        </div>
      </div>
    </div>);

}
function SectionBanner({
  title,
  subtitle



}: {title: string;subtitle: string;}) {
  return (
    <div className="relative w-full max-w-3xl mx-auto text-center">
      <div className="flex items-center justify-center gap-4 mb-2">
        <div className="h-px w-20 bg-gradient-to-r from-transparent to-megara-gold/60"></div>
        <div className="w-2 h-2 rotate-45 bg-megara-gold/70 shadow-[0_0_10px_rgba(212,168,87,0.6)]"></div>
        <div className="h-px w-20 bg-gradient-to-l from-transparent to-megara-gold/60"></div>
      </div>
      <h2
        className="font-cinzel text-2xl sm:text-3xl font-bold tracking-[0.22em] uppercase"
        style={{
          color: '#e9c97a',
          textShadow: '0 0 14px rgba(212,168,87,0.35), 0 2px 0 rgba(0,0,0,0.6)'
        }}>
        
        {title}
      </h2>
      <p className="font-cormorant italic text-megara-lavender/70 text-sm sm:text-base mt-2">
        {subtitle}
      </p>
    </div>);

}
/* ----- Month banner — carved stone tablet ----- */
function MonthBanner({ label, count }: {label: string;count: number;}) {
  return (
    <div className="flex justify-center">
      <div
        className="relative inline-flex items-center gap-3 px-8 py-2.5"
        style={{
          background:
          'linear-gradient(180deg, #4a2a55 0%, #2a1530 50%, #14081c 100%)',
          boxShadow:
          'inset 0 1px 0 rgba(212,168,87,0.4), inset 0 -1px 0 rgba(0,0,0,0.8), 0 6px 14px rgba(0,0,0,0.6), 0 0 24px rgba(170,40,100,0.25)',
          borderTop: '1px solid rgba(212,168,87,0.4)',
          borderBottom: '1px solid rgba(0,0,0,0.7)',
          clipPath: 'polygon(0 0, 100% 0, calc(100% - 16px) 100%, 16px 100%)'
        }}>
        
        <span className="block w-1.5 h-1.5 rotate-45 bg-megara-gold shadow-[0_0_8px_rgba(212,168,87,0.7)]"></span>
        <span
          className="font-cinzel font-bold text-lg sm:text-xl tracking-[0.32em] uppercase"
          style={{
            color: '#e9c97a',
            textShadow:
            '0 2px 0 rgba(0,0,0,0.9), 0 0 12px rgba(212,168,87,0.45)'
          }}>
          
          {label}
        </span>
        <span className="font-cormorant italic text-megara-lavender/70 text-xs">
          · {count} instructions
        </span>
        <span className="block w-1.5 h-1.5 rotate-45 bg-megara-gold shadow-[0_0_8px_rgba(212,168,87,0.7)]"></span>
      </div>
    </div>);

}
/* ----- Media banner — brass pill ----- */
function MediaBanner({ media, count }: {media: string;count: number;}) {
  return (
    <div className="flex items-center gap-3 max-w-5xl mx-auto">
      <div className="flex-1 h-px bg-gradient-to-r from-transparent to-megara-gold/30"></div>
      <div
        className="relative inline-flex items-center gap-2 px-4 py-1"
        style={{
          background:
          'linear-gradient(180deg, #e9c97a 0%, #c79a3e 45%, #8a5e1f 100%)',
          boxShadow:
          'inset 0 1px 0 rgba(255,240,200,0.6), inset 0 -1px 2px rgba(60,30,0,0.5), 0 2px 5px rgba(0,0,0,0.55), 0 0 14px rgba(212,168,87,0.25)',
          borderRadius: 2,
          clipPath: 'polygon(0 0, 100% 0, calc(100% - 10px) 100%, 10px 100%)'
        }}>
        
        <span className="w-1 h-1 rounded-full bg-megara-plum"></span>
        <span
          className="font-cinzel font-bold text-[11px] tracking-[0.3em] uppercase"
          style={{
            color: '#2a0f08'
          }}>
          
          {media}
        </span>
        <span className="font-cormorant italic text-[11px] text-[#3a1808]/85">
          · {count} {count === 1 ? 'market' : 'markets'}
        </span>
      </div>
      <div className="flex-1 h-px bg-gradient-to-l from-transparent to-megara-gold/30"></div>
    </div>);

}