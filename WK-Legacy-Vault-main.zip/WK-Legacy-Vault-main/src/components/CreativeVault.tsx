import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';
import { ApothecaryBottle } from './CreativeArtifacts';
/* ============================================================== */
/* CreativeVault — apothecary shelves of bottled creatives           */
/* ============================================================== */
interface Asset {
  id: string;
  title: string;
  year: number;
  category: string;
  accent: string;
  client: string;
}
const TITLES = [
'Different',
"Mother's Wreck",
'Strength',
'Personal',
'Weekends',
'Premise',
'Car Wreck',
'Commercial',
'More To Us',
'Distracted',
'Trucking',
'Holiday Push',
'Super Bowl',
'Reveal',
'Made Possible',
'The Man',
'Cityscape',
'Sunrise',
'Open Road',
'Tailgate',
'Game Day',
'Spring Bloom',
'Late Shift',
'Heatwave',
'Block Party',
'Field Day',
'Closing Bell',
'Last Call',
'Crowd Roar',
'Long Drive'];

const CATEGORIES = ['TV', 'Radio'];
const CLIENTS = [
'Wettermark Keith',
'Nike',
'Coca-Cola',
'Apple',
'Spotify',
'Old Spice',
'Airbnb',
'Patagonia',
'Delta',
'IKEA'];

const ACCENTS = [
'#5a2a78',
'#7a1f48',
'#1f4a78',
'#7a5a1f',
'#3a6a2a',
'#7a3a1f',
'#1f6a5a',
'#4a2a8a',
'#8a3a5a',
'#2a3a78'];

function generateAll(count: number): Asset[] {
  const out: Asset[] = [];
  for (let i = 0; i < count; i++) {
    out.push({
      id: `a-${i}`,
      title: TITLES[i * 7 % TITLES.length],
      year: 2008 + i * 5 % 18,
      category: CATEGORIES[i * 3 % CATEGORIES.length],
      accent: ACCENTS[i * 11 % ACCENTS.length],
      client: CLIENTS[i * 13 % CLIENTS.length]
    });
  }
  return out;
}
const ALL_ASSETS = generateAll(96);
const CATEGORY_FILTERS = ['All', ...CATEGORIES] as const;
export function CreativeVault() {
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState<(typeof CATEGORY_FILTERS)[number]>('All');
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return ALL_ASSETS.filter((a) => {
      if (cat !== 'All' && a.category !== cat) return false;
      if (!q) return true;
      return (
        a.title.toLowerCase().includes(q) ||
        a.client.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q) ||
        String(a.year).includes(q));

    });
  }, [query, cat]);
  // Group by year (descending), so shelves read top → bottom as newest → oldest
  const shelves = useMemo(() => {
    const map: Record<number, Asset[]> = {};
    for (const a of filtered) {
      if (!map[a.year]) map[a.year] = [];
      map[a.year].push(a);
    }
    return Object.entries(map).
    map(([y, items]) => ({
      year: Number(y),
      items
    })).
    sort((a, b) => b.year - a.year);
  }, [filtered]);
  return (
    <div>
      {/* Filter bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-10 max-w-5xl mx-auto">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-megara-gold/40" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search the apothecary — title, client, year…"
            className="w-full bg-black/40 border border-megara-gold/25 text-parchment-light font-eb py-2 pl-9 pr-3 rounded focus:outline-none focus:border-megara-gold/60 placeholder:text-parchment-light/30 transition-colors" />
          
        </div>
        <div className="flex flex-wrap gap-1.5">
          {CATEGORY_FILTERS.map((c) =>
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`font-cinzel text-[10px] tracking-[0.22em] uppercase px-2.5 py-1 rounded border transition-all ${cat === c ? 'bg-megara-gold/85 text-megara-dark border-megara-gold' : 'bg-transparent text-megara-gold/70 border-megara-gold/25 hover:bg-megara-gold/10 hover:text-megara-gold'}`}>
            
              {c}
            </button>
          )}
        </div>
        <div className="font-cormorant italic text-megara-lavender/65 text-sm">
          {filtered.length.toLocaleString()} of{' '}
          {ALL_ASSETS.length.toLocaleString()} bottles
        </div>
      </div>

      {/* Shelves */}
      <div className="flex flex-col gap-10">
        {shelves.length === 0 ?
        <div className="text-center font-cormorant italic text-megara-lavender/50 py-12">
            No bottles match that query.
          </div> :

        shelves.map(({ year, items }) =>
        <Shelf key={year} year={year} count={items.length}>
              {items.map((a, i) =>
          <ApothecaryBottle
            key={a.id}
            title={a.title}
            year={a.year}
            category={a.category}
            accent={a.accent}
            rotation={(i * 7 % 5 - 2) * 0.5} />

          )}
            </Shelf>
        )
        }
      </div>
    </div>);

}
/* ----- A wooden apothecary shelf ----- */
function Shelf({
  year,
  count,
  children




}: {year: number;count: number;children: React.ReactNode;}) {
  return (
    <motion.section
      initial={{
        opacity: 0,
        y: 20
      }}
      whileInView={{
        opacity: 1,
        y: 0
      }}
      viewport={{
        once: true,
        amount: 0.05
      }}
      transition={{
        duration: 0.5,
        ease: 'easeOut'
      }}
      className="relative">
      
      {/* Year banner — small brass plate floating left */}
      <div className="flex items-end gap-3 mb-2">
        <div
          className="inline-flex items-center gap-2 px-3 py-1"
          style={{
            background:
            'linear-gradient(180deg, #e9c97a 0%, #c79a3e 45%, #8a5e1f 100%)',
            boxShadow:
            'inset 0 1px 0 rgba(255,240,200,0.6), inset 0 -1px 2px rgba(60,30,0,0.5), 0 2px 5px rgba(0,0,0,0.55), 0 0 14px rgba(212,168,87,0.2)',
            clipPath: 'polygon(0 0, 100% 0, calc(100% - 10px) 100%, 10px 100%)'
          }}>
          
          <span className="w-1 h-1 rounded-full bg-megara-plum"></span>
          <span
            className="font-cinzel font-bold text-[11px] tracking-[0.3em] uppercase"
            style={{
              color: '#2a0f08'
            }}>
            
            {year}
          </span>
          <span className="font-cormorant italic text-[11px] text-[#3a1808]/85">
            · {count} {count === 1 ? 'bottle' : 'bottles'}
          </span>
        </div>
        <div className="flex-1 h-px bg-gradient-to-r from-megara-gold/30 to-transparent"></div>
      </div>

      {/* Bottles on the shelf */}
      <div className="relative">
        <div className="flex flex-wrap gap-x-2 gap-y-2 items-end pb-2 pl-2">
          {children}
        </div>

        {/* Wooden shelf plank */}
        <div className="relative h-3 -mt-1">
          <div
            className="absolute inset-x-0 top-0 h-3 rounded-sm"
            style={{
              background:
              'linear-gradient(180deg, #4a2a14 0%, #2a1408 60%, #14080a 100%)',
              boxShadow:
              'inset 0 1px 0 rgba(255,210,150,0.25), inset 0 -1px 0 rgba(0,0,0,0.7), 0 6px 12px rgba(0,0,0,0.65)',
              border: '1px solid #0a0604'
            }}>
          </div>
          {/* Wood grain lines */}
          <div
            className="absolute inset-x-0 top-0 h-3 opacity-30 mix-blend-overlay pointer-events-none"
            style={{
              backgroundImage:
              'repeating-linear-gradient(90deg, transparent 0px, transparent 12px, rgba(255,220,170,0.4) 13px, transparent 14px)'
            }}>
          </div>
        </div>
        {/* Shelf cast shadow below */}
        <div className="h-2 mx-4 bg-black/60 blur-md rounded-full -mt-1"></div>
      </div>
    </motion.section>);

}