import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Eye,
  Download,
  FileVideo,
  FileArchive,
  MonitorPlay,
  Search,
  ChevronLeft,
  ChevronRight,
  Quote } from
'lucide-react';
/**
 * CreativeLedger
 *
 * For ~4,210 creative pieces, one scroll per file makes no sense. Instead, the
 * Creative tab shows a single LARGE inventory scroll — a librarian's ledger —
 * with a dense, scannable list of every legacy creative asset and view/download
 * actions per row. Filter + paginate to navigate volume.
 */
interface CreativeRecord {
  isci: string;
  title: string;
  duration: string;
  year: number;
  market: string;
  media: 'TV' | 'Digital' | 'OOH' | 'Social' | 'Radio';
  client: string;
}
const CLIENTS = [
'Wettermark Keith',
'Nike',
'Coca-Cola',
'Apple',
'Spotify',
'Old Spice',
'Airbnb',
'Patagonia',
'Delta',
'IKEA'];

const MARKETS = [
'Huntsville',
'Birmingham',
'Mobile',
'US National',
'EMEA',
'APAC',
'WW'];

const MEDIA: CreativeRecord['media'][] = [
'TV',
'Digital',
'OOH',
'Social',
'Radio'];

const TITLES = [
'Different',
"Mother's Wreck",
'Strength in Confidence',
'Personal',
'Weekends',
'Premise Injury',
'Car Wreck',
'Commercial Accident',
'More To Us',
'Distracted Cell Phones',
'Trucking One',
'Holiday Push',
'Super Bowl Hero',
'Reveal',
'Made Possible',
'The Man'];

const DURATIONS = [':05', ':10', ':15', ':30', ':60'];
// Generate a stable, believable list of 4,210 creative records.
function generateRecords(count: number): CreativeRecord[] {
  const out: CreativeRecord[] = [];
  for (let i = 0; i < count; i++) {
    const client = CLIENTS[i % CLIENTS.length];
    const market = MARKETS[i * 3 % MARKETS.length];
    const media = MEDIA[i * 7 % MEDIA.length];
    const title = TITLES[i * 5 % TITLES.length];
    const duration = DURATIONS[i * 2 % DURATIONS.length];
    const year = 2008 + i * 11 % 18;
    const isciCode =
    market.slice(0, 3).toUpperCase() +
    client.
    replace(/[^A-Z]/gi, '').
    slice(0, 2).
    toUpperCase() +
    String(2500 + i % 1500).padStart(4, '0') +
    duration.replace(':', '').padStart(2, '0') +
    'T';
    out.push({
      isci: isciCode,
      title: `${title}_${duration.replace(':', '')}`,
      duration,
      year,
      market,
      media,
      client
    });
  }
  return out;
}
const ALL_RECORDS = generateRecords(4210);
const PAGE_SIZE = 40;
function MediaIcon({ media }: {media: CreativeRecord['media'];}) {
  if (media === 'TV') return <MonitorPlay className="w-3.5 h-3.5" />;
  if (media === 'OOH') return <FileArchive className="w-3.5 h-3.5" />;
  return <FileVideo className="w-3.5 h-3.5" />;
}
export function CreativeLedger() {
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(0);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return ALL_RECORDS;
    return ALL_RECORDS.filter(
      (r) =>
      r.isci.toLowerCase().includes(q) ||
      r.title.toLowerCase().includes(q) ||
      r.client.toLowerCase().includes(q) ||
      r.market.toLowerCase().includes(q)
    );
  }, [query]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);
  const start = safePage * PAGE_SIZE;
  const rows = filtered.slice(start, start + PAGE_SIZE);
  return (
    <motion.div
      initial={{
        opacity: 0,
        y: 30
      }}
      animate={{
        opacity: 1,
        y: 0
      }}
      transition={{
        duration: 0.6,
        type: 'spring',
        stiffness: 100,
        damping: 15
      }}>
      
      <div className="relative w-full max-w-6xl mx-auto bg-gradient-to-b from-parchment-light via-parchment to-parchment-dark shadow-[inset_0_0_60px_rgba(120,100,60,0.25),0_8px_30px_rgba(0,0,0,0.5)] border-y-2 border-megara-gold/40">
        <div className="p-6 sm:p-12">
          {/* Header */}
          <div className="flex flex-col items-center text-center mb-6 pb-4 border-b border-megara-wine/20">
            <div className="font-cinzel font-bold text-xs tracking-[0.3em] text-megara-dark uppercase">
              The Creative Inventory
            </div>
            <h2 className="font-cinzel text-2xl sm:text-3xl font-bold text-megara-wine tracking-wide mt-2">
              LIBER CREATIVUS
            </h2>
            <div className="font-cinzel text-xs tracking-[0.25em] text-megara-dark/70 uppercase mt-1">
              {ALL_RECORDS.length.toLocaleString()} legacy creative files · all
              known ghosts
            </div>
            <div className="mt-3 w-32 h-px bg-gradient-to-r from-transparent via-megara-gold to-transparent"></div>
          </div>

          {/* Quote */}
          <div className="font-cormorant italic text-megara-dark/70 text-base sm:text-lg text-center mb-6 flex items-center justify-center gap-2">
            <Quote className="w-4 h-4 text-megara-gold/60" />
            Every spot we ever cut. Every market we ever ran. All in one place.
          </div>

          {/* Search */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-megara-dark/40" />
              <input
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setPage(0);
                }}
                placeholder="Search the ledger — ISCI, title, client, market…"
                className="w-full bg-parchment-light border border-megara-wine/30 text-megara-dark font-eb py-2 pl-9 pr-3 rounded focus:outline-none focus:border-megara-gold placeholder:text-megara-dark/40 transition-colors" />
              
            </div>
            <div className="font-cormorant italic text-megara-dark/70 text-sm">
              Showing{' '}
              <span className="font-semibold text-megara-wine not-italic">
                {filtered.length === 0 ? 0 : start + 1}–
                {Math.min(start + PAGE_SIZE, filtered.length)}
              </span>{' '}
              of{' '}
              <span className="font-semibold text-megara-wine not-italic">
                {filtered.length.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Ledger Table */}
          <div className="border border-megara-wine/25 rounded-sm overflow-hidden">
            <table className="w-full font-eb text-sm text-megara-dark border-collapse">
              <thead>
                <tr className="bg-megara-wine/90 text-parchment-light text-left text-[10px] tracking-[0.22em] uppercase font-cinzel font-semibold">
                  <th className="py-2 px-3 w-12">#</th>
                  <th className="py-2 px-3">ISCI</th>
                  <th className="py-2 px-3">Title</th>
                  <th className="py-2 px-3 hidden md:table-cell">Client</th>
                  <th className="py-2 px-3 hidden md:table-cell">Market</th>
                  <th className="py-2 px-3 w-16">Year</th>
                  <th className="py-2 px-3 hidden sm:table-cell w-16">Dur</th>
                  <th className="py-2 px-3 hidden sm:table-cell w-20">Media</th>
                  <th className="py-2 px-3 w-24 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ?
                <tr>
                    <td
                    colSpan={9}
                    className="py-10 text-center font-cormorant italic text-megara-dark/60">
                    
                      No ghosts found in the ledger for that query.
                    </td>
                  </tr> :

                rows.map((r, i) =>
                <tr
                  key={`${r.isci}-${start + i}`}
                  className={`${(start + i) % 2 === 0 ? 'bg-parchment-light/40' : 'bg-transparent'} border-b border-parchment-shadow/30 hover:bg-megara-gold/15 transition-colors`}>
                  
                      <td className="py-2 px-3 font-cormorant italic text-megara-dark/60 tabular-nums">
                        {start + i + 1}
                      </td>
                      <td className="py-2 px-3 font-semibold text-megara-wine whitespace-nowrap">
                        {r.isci}
                      </td>
                      <td className="py-2 px-3 text-megara-dark">{r.title}</td>
                      <td className="py-2 px-3 hidden md:table-cell text-megara-dark/80">
                        {r.client}
                      </td>
                      <td className="py-2 px-3 hidden md:table-cell text-megara-dark/80">
                        {r.market}
                      </td>
                      <td className="py-2 px-3 tabular-nums text-megara-dark/80">
                        {r.year}
                      </td>
                      <td className="py-2 px-3 hidden sm:table-cell tabular-nums text-megara-dark/80">
                        {r.duration}
                      </td>
                      <td className="py-2 px-3 hidden sm:table-cell">
                        <span className="inline-flex items-center gap-1 text-megara-dark/80">
                          <MediaIcon media={r.media} />
                          {r.media}
                        </span>
                      </td>
                      <td className="py-2 px-3">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                        title="View"
                        className="p-1.5 rounded border border-megara-wine/30 text-megara-wine hover:bg-megara-wine hover:text-parchment transition-colors">
                        
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                        title="Download"
                        className="p-1.5 rounded bg-megara-wine text-parchment-light border border-megara-gold/40 hover:bg-megara-magenta transition-colors">
                        
                            <Download className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                )
                }
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="mt-6 flex items-center justify-between">
            <button
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={safePage === 0}
              className="flex items-center gap-1 px-3 py-1.5 font-cinzel text-xs tracking-[0.18em] uppercase text-megara-wine border border-megara-wine/30 rounded hover:bg-megara-wine hover:text-parchment disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
              
              <ChevronLeft className="w-3.5 h-3.5" />
              Prev
            </button>
            <div className="font-cormorant italic text-megara-dark/70 text-sm">
              Page{' '}
              <span className="font-semibold text-megara-wine not-italic">
                {safePage + 1}
              </span>{' '}
              of{' '}
              <span className="font-semibold text-megara-wine not-italic">
                {totalPages}
              </span>
            </div>
            <button
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={safePage >= totalPages - 1}
              className="flex items-center gap-1 px-3 py-1.5 font-cinzel text-xs tracking-[0.18em] uppercase text-megara-wine border border-megara-wine/30 rounded hover:bg-megara-wine hover:text-parchment disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
              
              Next
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>);

}