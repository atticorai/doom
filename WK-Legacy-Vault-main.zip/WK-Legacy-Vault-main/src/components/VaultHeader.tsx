import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Clapperboard } from 'lucide-react';
import { VaultArchway } from './VaultArchway';
export type VaultTab = 'instructions' | 'creative';
interface VaultHeaderProps {
  activeTab: VaultTab;
  onTabChange: (tab: VaultTab) => void;
}
export function VaultHeader({ activeTab, onTabChange }: VaultHeaderProps) {
  return (
    <div className="w-full max-w-6xl mx-auto">
      {/* Stone archway with carved title */}
      <VaultArchway>
        <motion.div
          initial={{
            opacity: 0,
            letterSpacing: '0.05em'
          }}
          animate={{
            opacity: 1,
            letterSpacing: '0.15em'
          }}
          transition={{
            duration: 1.2,
            ease: 'easeOut'
          }}
          className="font-cinzel text-[10px] sm:text-xs tracking-[0.35em] uppercase text-megara-gold/80 mb-1">
          
          ✦ Atticor · Doom & Deliverables ✦
        </motion.div>
        <motion.h1
          initial={{
            opacity: 0,
            y: -10
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 1,
            ease: 'easeOut'
          }}
          className="font-cinzel text-4xl md:text-6xl font-bold tracking-[0.08em] text-transparent bg-clip-text relative"
          style={{
            backgroundImage:
            'linear-gradient(180deg, #f7e6b8 0%, #d4a857 50%, #8a6a30 100%)',
            textShadow: '0 2px 0 rgba(0,0,0,0.6)',
            filter: 'drop-shadow(0 0 12px rgba(212,168,87,0.25))'
          }}>
          
          WK Legacy Vault
        </motion.h1>
        <motion.div
          initial={{
            opacity: 0
          }}
          animate={{
            opacity: 1
          }}
          transition={{
            duration: 1,
            delay: 0.4
          }}
          className="font-cormorant italic text-lg md:text-xl text-megara-lavender mt-2">
          
          "Welcome to my little corner of the underworld, sweetheart."
        </motion.div>
        <motion.div
          initial={{
            opacity: 0
          }}
          animate={{
            opacity: 1
          }}
          transition={{
            duration: 1,
            delay: 0.6
          }}
          className="font-eb text-megara-lavender/60 text-xs tracking-[0.18em] uppercase mt-3">
          
          1,402 instructions · 8,934 legacy ISCIs · 4,210 with creative
        </motion.div>
      </VaultArchway>

      {/* Brass plaque tagline */}
      <motion.div
        initial={{
          opacity: 0,
          y: 10
        }}
        animate={{
          opacity: 1,
          y: 0
        }}
        transition={{
          duration: 0.8,
          delay: 0.8
        }}
        className="mx-auto max-w-2xl mt-4 mb-8 text-center">
        
        <div className="inline-block px-6 py-2 border-y border-megara-gold/40 bg-gradient-to-r from-transparent via-megara-wine/10 to-transparent">
          <span className="font-cormorant italic text-megara-lavender/90 text-base md:text-lg">
            Every ghost of WK past, filed away by yours truly.
          </span>
        </div>
      </motion.div>

      {/* Stone-tablet tabs */}
      <div className="flex gap-3 sm:gap-4 relative justify-center mb-2 px-4">
        <TabButton
          label="Instructions"
          count="1,402"
          icon={<FileText className="w-4 h-4" />}
          active={activeTab === 'instructions'}
          onClick={() => onTabChange('instructions')} />
        
        <TabButton
          label="Creative"
          count="4,210"
          icon={<Clapperboard className="w-4 h-4" />}
          active={activeTab === 'creative'}
          onClick={() => onTabChange('creative')} />
        
      </div>
      <div className="h-px bg-gradient-to-r from-transparent via-megara-gold/40 to-transparent"></div>
    </div>);

}
function TabButton({
  label,
  count,
  icon,
  active,
  onClick






}: {label: string;count: string;icon: React.ReactNode;active: boolean;onClick: () => void;}) {
  return (
    <button onClick={onClick} className="relative group">
      <div
        className={`relative px-5 py-2.5 font-cinzel font-semibold text-sm tracking-[0.18em] uppercase rounded-sm transition-all border ${active ? 'text-megara-gold bg-gradient-to-b from-megara-plum/80 to-megara-dark/80 border-megara-gold/60 shadow-[0_0_18px_rgba(212,168,87,0.25),inset_0_1px_0_rgba(212,168,87,0.25)]' : 'text-megara-lavender/60 bg-gradient-to-b from-megara-dark/40 to-transparent border-megara-lavender/15 hover:text-megara-lavender hover:border-megara-lavender/30'}`}>
        
        <div className="flex items-center gap-2">
          {icon}
          <span>{label}</span>
          <span
            className={`font-eb text-[10px] tracking-normal normal-case ${active ? 'text-megara-gold/80' : 'text-megara-lavender/40'}`}>
            
            · {count}
          </span>
        </div>
        {active &&
        <motion.div
          layoutId="activeTab"
          className="absolute -bottom-px left-2 right-2 h-px bg-megara-gold shadow-[0_0_10px_rgba(212,168,87,0.7)]" />

        }
      </div>
    </button>);

}