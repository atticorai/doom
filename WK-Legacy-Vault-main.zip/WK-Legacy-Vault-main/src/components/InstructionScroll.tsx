import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Instruction } from './mockData';
import { ClosedScroll } from './ClosedScroll';
import { OpenScroll } from './OpenScroll';
interface InstructionScrollProps {
  instruction: Instruction;
  index: number;
}
/**
 * InstructionScroll
 *
 * Closed by default — renders a horizontal rolled-up scroll with a wax seal.
 * Click to unfurl into the full document.
 */
export function InstructionScroll({
  instruction,
  index
}: InstructionScrollProps) {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <motion.div
      initial={{
        opacity: 0,
        y: 20
      }}
      animate={{
        opacity: 1,
        y: 0
      }}
      transition={{
        duration: 0.5,
        delay: Math.min(index * 0.06, 0.4),
        type: 'spring',
        stiffness: 120,
        damping: 18
      }}
      className="inline-block">
      
      <ClosedScroll
        client={instruction.client}
        month={instruction.month}
        flight={instruction.flight}
        market={instruction.market}
        version={instruction.version}
        isOpen={isOpen}
        onClick={() => setIsOpen((v) => !v)}
        seedRotation={instruction.rotation} />
      
      <AnimatePresence initial={false}>
        {isOpen && <OpenScroll instruction={instruction} />}
      </AnimatePresence>
    </motion.div>);

}