import React, { Children } from 'react';
import { motion } from 'framer-motion';
/**
 * VaultArchway
 *
 * A stone archway carved into the top of the page — frames the vault title.
 * Two pilasters with a Greek-key keystone and a magenta glow inside the arch.
 */
export function VaultArchway({ children }: {children: React.ReactNode;}) {
  return (
    <div className="relative w-full max-w-5xl mx-auto pt-6">
      <svg
        viewBox="0 0 800 220"
        className="absolute inset-x-0 top-0 w-full h-auto pointer-events-none"
        xmlns="http://www.w3.org/2000/svg"
        preserveAspectRatio="none">
        
        <defs>
          <linearGradient id="archStone" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3a1f4a" />
            <stop offset="50%" stopColor="#5a3a70" />
            <stop offset="100%" stopColor="#2a1230" />
          </linearGradient>
          <linearGradient id="archStoneDark" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1a0c20" />
            <stop offset="100%" stopColor="#3a1f4a" />
          </linearGradient>
          <radialGradient id="archGlow" cx="0.5" cy="1" r="0.7">
            <stop offset="0%" stopColor="rgba(160,40,100,0.65)" />
            <stop offset="60%" stopColor="rgba(122,31,61,0.2)" />
            <stop offset="100%" stopColor="transparent" />
          </radialGradient>
        </defs>

        {/* Glow inside the arch */}
        <ellipse cx="400" cy="220" rx="320" ry="160" fill="url(#archGlow)" />

        {/* Arch curve */}
        <path
          d="M 80 220 L 80 100 Q 80 30 400 30 Q 720 30 720 100 L 720 220"
          fill="none"
          stroke="url(#archStone)"
          strokeWidth="10" />
        
        {/* Inner trim line */}
        <path
          d="M 90 220 L 90 105 Q 90 40 400 40 Q 710 40 710 105 L 710 220"
          fill="none"
          stroke="#d4a857"
          strokeWidth="0.8"
          opacity="0.7" />
        

        {/* Keystone */}
        <g>
          <path
            d="M 380 35 L 420 35 L 425 70 L 375 70 Z"
            fill="url(#archStone)"
            stroke="#d4a857"
            strokeWidth="0.8" />
          
          {/* Tiny laurel in keystone */}
          <circle
            cx="400"
            cy="52"
            r="6"
            fill="none"
            stroke="#d4a857"
            strokeWidth="0.6" />
          
          <text
            x="400"
            y="56"
            textAnchor="middle"
            fontFamily="Cinzel, serif"
            fontSize="8"
            fontWeight="700"
            fill="#d4a857">
            
            WK
          </text>
        </g>

        {/* Left pilaster cap */}
        <rect
          x="55"
          y="195"
          width="50"
          height="10"
          fill="url(#archStoneDark)"
          stroke="#d4a857"
          strokeWidth="0.5" />
        
        {/* Right pilaster cap */}
        <rect
          x="695"
          y="195"
          width="50"
          height="10"
          fill="url(#archStoneDark)"
          stroke="#d4a857"
          strokeWidth="0.5" />
        
      </svg>

      {/* Children sit underneath the arch SVG, with breathing room */}
      <motion.div
        initial={{
          opacity: 0,
          y: 8
        }}
        animate={{
          opacity: 1,
          y: 0
        }}
        transition={{
          duration: 0.8
        }}
        className="relative pt-24 sm:pt-28 pb-4 px-6 text-center">
        
        {children}
      </motion.div>
    </div>);

}