
/** @type {import('tailwindcss').Config} */
export default {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        megara: {
          dark: '#1a0a1f',
          plum: '#2a0f2e',
          wine: '#7a1f3d',
          magenta: '#a02850',
          lavender: '#c9a8d4',
          gold: '#d4a857',
          'gold-dark': '#b8924a',
        },
        parchment: {
          light: '#f4ebd8',
          DEFAULT: '#e8dcc0',
          dark: '#d4c4a0',
          shadow: '#b5a37a',
        }
      },
      fontFamily: {
        cinzel: ['Cinzel', 'serif'],
        cormorant: ['Cormorant Garamond', 'serif'],
        eb: ['EB Garamond', 'serif'],
      },
      backgroundImage: {
        'vault-radial': 'radial-gradient(circle at center top, #3d1742 0%, #2a0f2e 40%, #1a0a1f 100%)',
      }
    },
  },
  plugins: [],
}
